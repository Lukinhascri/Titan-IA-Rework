# TITAN — análise técnica assistida (Android)

App Android (Kotlin + Jetpack Compose) com bolinha flutuante, leitura autorizada da tela, análise técnica,
Confirmation System, Radar, alertas, estatísticas, TITAN Lab, Auto Trade **somente simulado**, Copilot e calendário.

> **STATUS HONESTO — leia antes de usar**
> - O código **não foi compilado nem testado em aparelho** no ambiente onde foi escrito (sem Android SDK/Gradle/rede).
>   A primeira execução do GitHub Actions pode apontar erros de compilação; envie o log e eu corrijo.
> - Os testes unitários (`app/src/test`) existem, mas **ainda não foram executados**. Nenhum resultado de teste é afirmado aqui.
> - TITAN **não garante resultados**. Análises são hipóteses baseadas em dados passados.

## Integração com a Avalon (limitação principal)
- Em uma busca inicial **não foi encontrada API oficial nem documentação pública** da Avalon. Logo, **não existe integração por API** neste código (nada foi inventado).
- Caminho implementado: **leitura visual autorizada** (captura de tela pelo diálogo oficial do Android + OCR offline + extração de velas por cor).
- **Modo independente** = dados que *você* importa (CSV). **Modo híbrido** = compara leitura visual x CSV e avisa inconsistências.
- A interface `AvalonDataSource` está pronta para plugar uma API oficial se ela existir.
- Limitações da leitura visual: preço vindo do print é **relativo** (pixels); cores das velas/região do gráfico precisam de **calibração** (Config. > Calibração visual); OCR pode errar ativo/tempo gráfico; relógio da vela x expiração são distinguidos por heurística (posição/palavra "expir") — confira na tela. Navegador em modo anônimo pode bloquear captura.
- O Radar só enxerga ativos já vistos/importados; a lista de ativos da Avalon não é acessível.

## O que está implementado
| Área | Situação |
|---|---|
| Identidade (logo, ícone adaptativo, tema escuro azul/roxo) | implementado |
| Bolinha flutuante (arrastar, minimizar por toque longo, ocultar/mostrar/fechar na notificação, status conexão/análise/alerta/erro) | implementado, não testado em aparelho |
| Captura de tela autorizada (MediaProjection, serviço em 1º plano, notificação com "Parar") | implementado, não testado |
| OCR (ML Kit offline): plataforma, ativo, tempo gráfico, preço, relógios | implementado, heurístico |
| 16 indicadores (RSI, MACD, EMA, SMA, VWAP, Bollinger, ATR, ADX, Estocástico, CCI, OBV, Ichimoku, SAR, Fibonacci, Volume Profile, Pivots) | implementado; VWAP/OBV só com volume |
| 15 padrões de velas | implementado (regras geométricas) |
| Padrões gráficos (OCO/OCOI, topo/fundo duplo, triângulos, bandeira, flâmula, cunhas, canais, retângulo, rompimento/falso) | implementado por **heurística** de swings |
| Dow, BOS, sweep de liquidez, FVG (SMC/ICT objetivos) | implementado |
| **Wyckoff e Ondas de Elliott** | **NÃO implementado** (subjetivos demais para automatizar com honestidade); Fluxo de ordens: sem dados, não implementado |
| Multi-tempo (agrega velas para 5/15/30/60 e mostra desacordos) | implementado (a partir da série carregada) |
| Confirmation System (Vision, Technical, Quant, Market, Auditor, Decision Engine) | implementado |
| Alertas (oportunidade/confirmação/ausência, critérios, contagem regressiva, cancelamento) | implementado |
| Radar com ranking transparente | implementado |
| Estatísticas (simulado x real importado separados) e memória de desempenho | implementado; nada é inventado |
| Proteção de capital (limites, pausa, emergência, log) | implementado (sobre simulações) |
| TITAN Lab (backtest, fora da amostra 70/30, walk-forward, drawdown, expectativa, custos) | implementado |
| Auto Trade | **somente paper trading**; sem ordens reais, sem senhas |
| Copilot | por **regras** (glossário + dados do app); não é LLM |
| Calendário econômico | **importação de CSV/manual** com fonte e data; sem busca automática (sem fonte autorizada configurada) |
| Rede: reconexão com backoff, latência, consumo de dados | implementado |

## Estrutura
```
app/src/main/java/com/titan/app/
  core/ (modelos, estado, Pipeline)     indicators/   patterns/   strategies/
  analysis/ (agentes, multi-tempo)      vision/ (OCR, velas, captura)
  avalon/   floating/   alerts/   risk/   lab/   autotrade/   copilot/   calendar/
  data/ (SQLite, séries, estatísticas)  net/   ui/ (tema, 10 abas)
app/src/test/ (testes unitários)   .github/workflows/build-apk.yml   docs/TUTORIAL_CELULAR.md
```

## Tecnologias
Kotlin 1.9.24, Compose (BOM 2024.06), Material3, ML Kit Text Recognition (offline), SQLite, Coroutines. minSdk 26, targetSdk 34. Gradle 8.7 / AGP 8.5.2 / JDK 17.

## Formatos de CSV
- Velas: `timestamp,open,high,low,close[,volume]`
- Calendário: `AAAA-MM-DD HH:mm;país;evento;importância 1-3;fonte;data da fonte`
- Operações reais: `AAAA-MM-DD HH:mm;ativo;tempo;estratégia;direção 1/-1;entrada;saída;valor;WIN|LOSS|TIE;lucro`

## Compilar / instalar / atualizar
Veja `docs/TUTORIAL_CELULAR.md` (tudo pelo celular, via GitHub Actions). O APK é assinado com uma chave de debug **fixa** versionada em `app/titan-debug.keystore`, por isso novas versões instalam **por cima** da anterior sem desinstalar.
(Chave de debug é pública: não use para publicar na Play Store.)

## Aviso de risco
Operações em plataformas de opções/derivativos envolvem alto risco de perda. Taxa de acerto precisa superar o ponto de equilíbrio do payout (ex.: 80% de payout exige ~55,6%). O app mostra isso, mas não elimina o risco.
