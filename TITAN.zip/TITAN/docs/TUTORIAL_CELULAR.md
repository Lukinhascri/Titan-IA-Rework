# Tutorial — compilar o TITAN só com o celular

## 1. Baixar o ZIP
Baixe `TITAN.zip` no celular e **extraia** (app "Arquivos" ou "ZArchiver"). Você terá a pasta `TITAN` com `app/`, `.github/`, `settings.gradle.kts` etc.
**Importante:** a pasta oculta `.github` precisa ir junto (ative "mostrar arquivos ocultos").

## 2. Conta no GitHub
Abra github.com no Chrome > Sign up > confirme o e-mail.

## 3. Criar o repositório
Botão **+** > New repository > nome `TITAN` > **Private** > Create repository.

## 4. Enviar os arquivos pelo navegador
No repositório: **Add file > Upload files**. Envie o conteúdo da pasta extraída (mantendo as subpastas — o upload do GitHub aceita pastas no Chrome com "Selecionar pasta" ou pelo modo "Versão para computador" do Chrome).
Se `.github/workflows/build-apk.yml` não subir, use **Add file > Create new file**, digite `.github/workflows/build-apk.yml` como nome e cole o conteúdo do arquivo.
Confirme com **Commit changes**.

## 5. Executar o GitHub Actions
Aba **Actions** > "Build TITAN APK" > **Run workflow** (também roda sozinho a cada commit). Se pedir, clique em "I understand my workflows, enable them".

## 6. Acompanhar
Abra a execução (bolinha amarela = rodando, verde = ok, vermelha = erro). Leva ~5–10 min.
**Se der erro (vermelho):** abra o passo que falhou, copie as últimas ~40 linhas do log e me envie. É esperado precisar de ajustes na primeira compilação.

## 7. Baixar o APK
Na execução concluída, role até **Artifacts** > `TITAN-apk` (baixa um ZIP) > extraia > `app-debug.apk`.

## 8. Instalar
Abra o `app-debug.apk` > permita "Instalar apps desconhecidos" para o app que você usou > Instalar.
No TITAN: **Ativar bolinha** (conceda "Sobrepor a outros apps") e **Autorizar captura** (diálogo do Android; escolha "Tela inteira"). Abra a Avalon no Chrome. Em Config. > Calibração visual, ajuste as cores das velas e a região do gráfico usando um print real.

## 9. Atualizar
Quando eu enviar arquivos novos: substitua-os no repositório (Add file > Upload files, mesmo caminho, **Commit**), espere o Actions e baixe o novo APK. Instale **por cima** (a assinatura é a mesma, seus dados ficam).
