package com.titan.app

import com.titan.app.analysis.AnalysisConfig
import com.titan.app.analysis.DecisionEngine
import com.titan.app.analysis.Timeframes
import com.titan.app.core.Bias
import com.titan.app.core.Candle
import com.titan.app.core.DataOrigin
import com.titan.app.core.SignalKind
import com.titan.app.data.SeriesStore
import com.titan.app.lab.BtConfig
import com.titan.app.lab.Backtester
import com.titan.app.patterns.CandlePatterns
import com.titan.app.strategies.EmaCross
import com.titan.app.strategies.Strategies
import org.junit.Assert.*
import org.junit.Test

class EngineTest {
    @Test fun bullishEngulfingDetected() {
        val base = List(8) { Candle(it.toLong(), 100.0 - it, 100.5 - it, 98.5 - it, 99.0 - it) }  // queda
        val prev = Candle(8, 92.0, 92.2, 90.0, 90.5)      // vela de baixa
        val cur = Candle(9, 90.2, 93.5, 90.0, 93.0)       // engolfa
        val hits = CandlePatterns.detect(base + prev + cur)
        assertTrue(hits.any { it.name == "Engolfo de alta" })
    }
    @Test fun csvParserHandlesHeaderAndBadRows() {
        val csv = "time,open,high,low,close,volume\n1,10,11,9,10.5,100\n2,10.5,12,10,11,120\nlixo\n3,11,10,12,11,1\n"
        val (cs, bad) = SeriesStore.parseCsv(csv.byteInputStream())
        assertEquals(2, cs.size); assertEquals(2, bad)
    }
    @Test fun timeframeParsing() {
        assertEquals(5, Timeframes.minutes("M5")); assertEquals(60, Timeframes.minutes("H1")); assertEquals(15, Timeframes.minutes("15m"))
        assertNull(Timeframes.minutes("xyz"))
    }
    @Test fun aggregateKeepsOhlc() {
        val cs = listOf(Candle(0, 1.0, 2.0, 0.5, 1.5), Candle(1, 1.5, 3.0, 1.0, 2.0))
        val a = Timeframes.aggregate(cs, 2)
        assertEquals(1, a.size); assertEquals(1.0, a[0].o, 0.0); assertEquals(3.0, a[0].h, 0.0); assertEquals(0.5, a[0].l, 0.0); assertEquals(2.0, a[0].c, 0.0)
    }
    @Test fun backtestHasNoLookaheadAndCountsConsistently() {
        val cs = SeriesStore.synthetic(800)
        for (s in Strategies.all) {
            val r = Backtester.run(cs, s, BtConfig())
            assertEquals(r.trades, r.wins + r.losses + r.ties)
            assertTrue(r.winRate in 0.0..1.0)
        }
    }
    @Test fun signalsAreCausal() {
        // alterar candles FUTUROS não pode mudar sinais passados
        val cs = SeriesStore.synthetic(300)
        val altered = cs.toMutableList()
        for (i in 250 until 300) altered[i] = Candle(i.toLong(), 500.0, 501.0, 499.0, 500.5)
        val a = EmaCross.signals(cs); val b = EmaCross.signals(altered)
        for (i in 0 until 250) assertEquals(a[i], b[i])
    }
    @Test fun demoDataIsBlockedByAuditor() {
        val d = DecisionEngine.decide("DEMO", "M1", SeriesStore.synthetic(), DataOrigin.SINTETICO_DEMO, null, AnalysisConfig())
        assertEquals(SignalKind.AUSENCIA_DE_SINAL, d.kind); assertEquals(Bias.NEUTRO, d.bias)
    }
    @Test fun tooFewCandlesGivesNoSignal() {
        val d = DecisionEngine.decide("X", "M1", SeriesStore.synthetic(20), DataOrigin.IMPORTADO, null, AnalysisConfig())
        assertEquals(SignalKind.AUSENCIA_DE_SINAL, d.kind); assertNull(d.statConfidence)
    }
}
