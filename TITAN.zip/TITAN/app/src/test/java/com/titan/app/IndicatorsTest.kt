package com.titan.app

import com.titan.app.analysis.Stats
import com.titan.app.core.Candle
import com.titan.app.indicators.Indicators
import com.titan.app.indicators.closes
import org.junit.Assert.*
import org.junit.Test

class IndicatorsTest {
    @Test fun smaBasic() {
        val r = Indicators.sma(doubleArrayOf(1.0, 2.0, 3.0, 4.0, 5.0), 3)
        assertTrue(r[0].isNaN() && r[1].isNaN())
        assertEquals(2.0, r[2], 1e-9); assertEquals(4.0, r[4], 1e-9)
    }
    @Test fun emaSeedIsSma() {
        val r = Indicators.ema(doubleArrayOf(1.0, 2.0, 3.0, 4.0), 3)
        assertEquals(2.0, r[2], 1e-9)
        assertEquals(3.0, r[3], 1e-9)   // 4*0.5 + 2*0.5
    }
    @Test fun rsiMonotonicUpIs100() {
        val c = DoubleArray(40) { it.toDouble() }
        assertEquals(100.0, Indicators.rsi(c, 14).last(), 1e-9)
    }
    @Test fun rsiMonotonicDownIs0() {
        val c = DoubleArray(40) { 100.0 - it }
        assertEquals(0.0, Indicators.rsi(c, 14).last(), 1e-9)
    }
    @Test fun bollingerFlatSeriesHasZeroWidth() {
        val b = Indicators.bollinger(DoubleArray(30) { 10.0 })
        assertEquals(10.0, b.upper.last(), 1e-9); assertEquals(10.0, b.lower.last(), 1e-9)
    }
    @Test fun macdLengthAndNaNPrefix() {
        val m = Indicators.macd(DoubleArray(60) { it * 0.5 })
        assertEquals(60, m.line.size); assertTrue(m.line[10].isNaN()); assertFalse(m.line[59].isNaN())
    }
    @Test fun atrConstantRange() {
        val h = DoubleArray(30) { 11.0 }; val l = DoubleArray(30) { 9.0 }; val c = DoubleArray(30) { 10.0 }
        assertEquals(2.0, Indicators.atr(h, l, c, 14).last(), 1e-9)
    }
    @Test fun obvAndVwapWithoutVolumeAreHonest() {
        val c = doubleArrayOf(1.0, 2.0, 1.5)
        assertEquals(0.0, Indicators.obv(c, doubleArrayOf(0.0, 0.0, 0.0)).last(), 1e-9)
        assertTrue(Indicators.vwap(c, c, c, doubleArrayOf(0.0, 0.0, 0.0)).last().isNaN())
    }
    @Test fun fibonacciUpTrend618() {
        val f = Indicators.fibonacci(200.0, 100.0, true)
        assertEquals(138.2, f["61.8%"]!!, 1e-6)
    }
    @Test fun pivotClassic() {
        val p = Indicators.pivots(12.0, 8.0, 10.0)
        assertEquals(10.0, p.p, 1e-9); assertEquals(12.0, p.r1, 1e-9); assertEquals(8.0, p.s1, 1e-9)
    }
    @Test fun wilsonAndBreakEven() {
        val (lo, hi) = Stats.wilson(50, 100)
        assertTrue(lo < 0.5 && hi > 0.5)
        assertEquals(1.0 / 1.8, Stats.breakEven(0.8), 1e-9)
        val small = Stats.wilson(3, 3)
        assertTrue(small.first < 0.5)  // 3/3 não prova nada
    }
}
