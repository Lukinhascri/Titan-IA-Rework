package com.titan.app.strategies

import com.titan.app.core.Candle
import com.titan.app.indicators.*

/**
 * Estratégia = função que, para CADA índice i, devolve +1 (viés de alta), -1 (viés de baixa) ou 0,
 * usando somente dados até o índice i (sem vazamento do futuro: todos os indicadores acima são causais).
 */
interface Strategy {
    val id: String
    val name: String
    fun signals(cs: List<Candle>): IntArray
}

private fun crossUp(a: DoubleArray, b: DoubleArray, i: Int) =
    i > 0 && !a[i].isNaN() && !b[i].isNaN() && !a[i - 1].isNaN() && !b[i - 1].isNaN() && a[i - 1] <= b[i - 1] && a[i] > b[i]

private fun crossDown(a: DoubleArray, b: DoubleArray, i: Int) =
    i > 0 && !a[i].isNaN() && !b[i].isNaN() && !a[i - 1].isNaN() && !b[i - 1].isNaN() && a[i - 1] >= b[i - 1] && a[i] < b[i]

object RsiReversal : Strategy {
    override val id = "RSI_REV"; override val name = "RSI reversão (30/70)"
    override fun signals(cs: List<Candle>): IntArray {
        val r = Indicators.rsi(cs.closes(), 14)
        return IntArray(cs.size) { i ->
            if (i == 0 || r[i].isNaN() || r[i - 1].isNaN()) 0
            else if (r[i - 1] < 30 && r[i] >= 30) 1
            else if (r[i - 1] > 70 && r[i] <= 70) -1 else 0
        }
    }
}

object EmaCross : Strategy {
    override val id = "EMA_CROSS"; override val name = "Cruzamento EMA 9/21"
    override fun signals(cs: List<Candle>): IntArray {
        val c = cs.closes(); val a = Indicators.ema(c, 9); val b = Indicators.ema(c, 21)
        return IntArray(cs.size) { if (crossUp(a, b, it)) 1 else if (crossDown(a, b, it)) -1 else 0 }
    }
}

object MacdCross : Strategy {
    override val id = "MACD_CROSS"; override val name = "Cruzamento MACD"
    override fun signals(cs: List<Candle>): IntArray {
        val m = Indicators.macd(cs.closes())
        return IntArray(cs.size) { if (crossUp(m.line, m.signal, it)) 1 else if (crossDown(m.line, m.signal, it)) -1 else 0 }
    }
}

object BollingerReversion : Strategy {
    override val id = "BB_REV"; override val name = "Bollinger reversão"
    override fun signals(cs: List<Candle>): IntArray {
        val c = cs.closes(); val b = Indicators.bollinger(c)
        return IntArray(cs.size) { i ->
            if (i == 0 || b.lower[i].isNaN() || b.lower[i - 1].isNaN()) 0
            else if (c[i - 1] < b.lower[i - 1] && c[i] >= b.lower[i]) 1
            else if (c[i - 1] > b.upper[i - 1] && c[i] <= b.upper[i]) -1 else 0
        }
    }
}

object StochExtremes : Strategy {
    override val id = "STOCH"; override val name = "Estocástico extremos"
    override fun signals(cs: List<Candle>): IntArray {
        val (k, d) = Indicators.stochastic(cs.highs(), cs.lows(), cs.closes())
        return IntArray(cs.size) { i ->
            if (!k[i].isNaN() && !d[i].isNaN() && crossUp(k, d, i) && k[i] < 25) 1
            else if (!k[i].isNaN() && !d[i].isNaN() && crossDown(k, d, i) && k[i] > 75) -1 else 0
        }
    }
}

object TrendPullback : Strategy {
    override val id = "TREND_PULLBACK"; override val name = "Pullback na tendência (EMA50 + RSI)"
    override fun signals(cs: List<Candle>): IntArray {
        val c = cs.closes(); val e = Indicators.ema(c, 50); val r = Indicators.rsi(c, 14)
        return IntArray(cs.size) { i ->
            if (i == 0 || e[i].isNaN() || r[i].isNaN() || r[i - 1].isNaN()) 0
            else if (c[i] > e[i] && r[i - 1] < 45 && r[i] >= 45) 1
            else if (c[i] < e[i] && r[i - 1] > 55 && r[i] <= 55) -1 else 0
        }
    }
}

object Strategies {
    val all: List<Strategy> = listOf(RsiReversal, EmaCross, MacdCross, BollingerReversion, StochExtremes, TrendPullback)
    fun byId(id: String) = all.firstOrNull { it.id == id }
}
