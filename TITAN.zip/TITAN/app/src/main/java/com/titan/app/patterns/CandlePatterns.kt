package com.titan.app.patterns

import com.titan.app.core.Bias
import com.titan.app.core.Candle
import kotlin.math.abs

data class PatternHit(val name: String, val index: Int, val bias: Bias, val note: String = "")

/**
 * Padrões de velas por regras geométricas simples (heurísticas clássicas).
 * O contexto de tendência prévia é estimado pelas 5 velas anteriores.
 * Nenhum padrão é garantia de reversão/continuação.
 */
object CandlePatterns {
    private fun priorTrend(cs: List<Candle>, i: Int, n: Int = 5): Int {
        if (i < n) return 0
        val d = cs[i - 1].c - cs[i - n].c
        val thr = avgRange(cs, i) * 0.8
        return when {
            d > thr -> 1
            d < -thr -> -1
            else -> 0
        }
    }

    private fun avgRange(cs: List<Candle>, i: Int, n: Int = 10): Double {
        val from = maxOf(0, i - n)
        val sl = cs.subList(from, maxOf(from + 1, i))
        return sl.map { it.range }.average().let { if (it.isNaN() || it == 0.0) 1e-9 else it }
    }

    fun detect(cs: List<Candle>, onlyLast: Int = 0): List<PatternHit> {
        val out = mutableListOf<PatternHit>()
        val start = if (onlyLast > 0) maxOf(2, cs.size - onlyLast) else 2
        for (i in start until cs.size) {
            val c = cs[i]; val p = cs[i - 1]; val pp = cs[i - 2]
            if (c.range <= 0) continue
            val tr = priorTrend(cs, i)
            val ar = avgRange(cs, i)
            val bodyRatio = c.body / c.range

            if (bodyRatio < 0.1) out += PatternHit("Doji", i, Bias.NEUTRO, "indecisão")
            if (c.bullish && c.body > 0 && c.lowerWick >= 2 * c.body && c.upperWick <= 0.3 * c.body + 1e-12 && tr < 0)
                out += PatternHit("Martelo", i, Bias.ALTA)
            if (c.body > 0 && c.upperWick >= 2 * c.body && c.lowerWick <= 0.3 * c.body + 1e-12 && tr < 0)
                out += PatternHit("Martelo invertido", i, Bias.ALTA)
            if (c.body > 0 && c.upperWick >= 2 * c.body && c.lowerWick <= 0.3 * c.body + 1e-12 && tr > 0)
                out += PatternHit("Shooting Star", i, Bias.BAIXA)
            if (c.body > 0 && c.lowerWick >= 2 * c.body && c.upperWick <= 0.3 * c.body + 1e-12 && tr > 0)
                out += PatternHit("Hanging Man", i, Bias.BAIXA)
            if (p.bearish && c.bullish && c.o <= p.c && c.c >= p.o && c.body > p.body)
                out += PatternHit("Engolfo de alta", i, Bias.ALTA)
            if (p.bullish && c.bearish && c.o >= p.c && c.c <= p.o && c.body > p.body)
                out += PatternHit("Engolfo de baixa", i, Bias.BAIXA)
            // Harami: corpo atual contido no corpo anterior (que é grande)
            if (p.body > 0.6 * ar && c.body < p.body * 0.6 &&
                maxOf(c.o, c.c) <= maxOf(p.o, p.c) && minOf(c.o, c.c) >= minOf(p.o, p.c)) {
                if (p.bearish && c.bullish) out += PatternHit("Harami de alta", i, Bias.ALTA)
                else if (p.bullish && c.bearish) out += PatternHit("Harami de baixa", i, Bias.BAIXA)
            }
            // Estrela da manhã / noite (3 velas)
            val smallMid = p.body < 0.35 * pp.body
            if (pp.bearish && pp.body > 0.6 * ar && smallMid && c.bullish && c.c > (pp.o + pp.c) / 2)
                out += PatternHit("Estrela da manhã", i, Bias.ALTA)
            if (pp.bullish && pp.body > 0.6 * ar && smallMid && c.bearish && c.c < (pp.o + pp.c) / 2)
                out += PatternHit("Estrela da noite", i, Bias.BAIXA)
            // Piercing / Dark Cloud
            if (p.bearish && c.bullish && c.o < p.c && c.c > (p.o + p.c) / 2 && c.c < p.o)
                out += PatternHit("Piercing Line", i, Bias.ALTA)
            if (p.bullish && c.bearish && c.o > p.c && c.c < (p.o + p.c) / 2 && c.c > p.o)
                out += PatternHit("Dark Cloud Cover", i, Bias.BAIXA)
            // Marubozu
            if (bodyRatio > 0.95 && c.body > 0.8 * ar)
                out += PatternHit("Marubozu", i, if (c.bullish) Bias.ALTA else Bias.BAIXA)
            // Três soldados / três corvos
            if (i >= 2) {
                val a = pp; val b = p
                if (a.bullish && b.bullish && c.bullish && b.c > a.c && c.c > b.c &&
                    b.o > a.o && c.o > b.o && a.body > 0.5 * ar && b.body > 0.5 * ar && c.body > 0.5 * ar)
                    out += PatternHit("Três soldados brancos", i, Bias.ALTA)
                if (a.bearish && b.bearish && c.bearish && b.c < a.c && c.c < b.c &&
                    b.o < a.o && c.o < b.o && a.body > 0.5 * ar && b.body > 0.5 * ar && c.body > 0.5 * ar)
                    out += PatternHit("Três corvos negros", i, Bias.BAIXA)
            }
        }
        return out
    }
}
