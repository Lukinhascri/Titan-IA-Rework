package com.titan.app.data

import androidx.compose.runtime.mutableStateMapOf
import com.titan.app.core.Candle
import com.titan.app.core.DataOrigin
import java.io.InputStream
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

data class Series(val asset: String, val timeframe: String, val origin: DataOrigin, val candles: List<Candle>, val updatedAt: Long)

/** Séries em memória (ativo|tempo gráfico). Origem sempre registrada: VISUAL, IMPORTADO ou SINTETICO_DEMO. */
object SeriesStore {
    val map = mutableStateMapOf<String, Series>()

    fun key(asset: String, tf: String) = "$asset|$tf"
    fun put(s: Series) { map[key(s.asset, s.timeframe)] = s }
    fun get(asset: String, tf: String): Series? = map[key(asset, tf)]
    fun all(): List<Series> = map.values.sortedBy { it.asset }

    /**
     * CSV com colunas FIXAS: timestamp,open,high,low,close[,volume]. O timestamp pode ser qualquer texto/número.
     * Cabeçalho (primeira linha não numérica) é ignorado; linhas inválidas são ignoradas e contadas.
     */
    fun parseCsv(input: InputStream): Pair<List<Candle>, Int> {
        val out = mutableListOf<Candle>(); var bad = 0; var idx = 0L; var first = true
        input.bufferedReader().useLines { lines ->
            for (line in lines) {
                if (line.isBlank()) continue
                val p = line.trim().split(',', ';', '\t').map { it.trim() }
                val nums = p.drop(1).map { it.toDoubleOrNull() }
                if (first) { first = false; if (nums.take(4).any { it == null }) continue }  // cabeçalho
                if (p.size < 5 || nums.take(4).any { it == null }) { bad++; continue }
                val o = nums[0]!!; val h = nums[1]!!; val l = nums[2]!!; val c = nums[3]!!
                if (h < l || h < maxOf(o, c) - 1e-12 || l > minOf(o, c) + 1e-12) { bad++; continue }
                out += Candle(p[0].toLongOrNull() ?: idx, o, h, l, c, nums.getOrNull(4) ?: 0.0)
                idx++
            }
        }
        return out to bad
    }

    /** Dados SINTÉTICOS (passeio aleatório + ciclo). Servem apenas para testar o app; jamais entram em estatísticas. */
    fun synthetic(n: Int = 600, seed: Int = 7): List<Candle> {
        val r = Random(seed); var p = 100.0
        return List(n) { i ->
            val o = p
            val c = o + r.nextDouble(-0.5, 0.5) + 0.15 * sin(2 * PI * i / 90.0)
            val h = maxOf(o, c) + r.nextDouble(0.0, 0.3)
            val l = minOf(o, c) - r.nextDouble(0.0, 0.3)
            p = c
            Candle(i.toLong(), o, h, l, c, r.nextDouble(100.0, 1000.0))
        }
    }
}
