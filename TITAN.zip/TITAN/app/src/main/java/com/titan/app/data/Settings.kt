package com.titan.app.data

import android.content.Context
import android.content.SharedPreferences

/** Configurações do usuário. NENHUM módulo altera estes valores automaticamente. */
class Settings(ctx: Context) {
    private val sp: SharedPreferences = ctx.getSharedPreferences("titan_settings", Context.MODE_PRIVATE)

    var payout: Float get() = sp.getFloat("payout", 0.80f); set(v) = sp.edit().putFloat("payout", v).apply()
    var stake: Float get() = sp.getFloat("stake", 10f); set(v) = sp.edit().putFloat("stake", v).apply()
    var maxLossDay: Float get() = sp.getFloat("maxLossDay", 50f); set(v) = sp.edit().putFloat("maxLossDay", v).apply()
    var maxOpsDay: Int get() = sp.getInt("maxOpsDay", 20); set(v) = sp.edit().putInt("maxOpsDay", v).apply()
    var pauseAfterLosses: Int get() = sp.getInt("pauseAfterLosses", 3); set(v) = sp.edit().putInt("pauseAfterLosses", v).apply()
    var emergencyStop: Boolean get() = sp.getBoolean("emergency", false); set(v) = sp.edit().putBoolean("emergency", v).apply()
    var captureIntervalSec: Int get() = sp.getInt("captureInterval", 5); set(v) = sp.edit().putInt("captureInterval", v).apply()
    var mode: String get() = sp.getString("mode", "VISUAL") ?: "VISUAL"; set(v) = sp.edit().putString("mode", v).apply()
    var alertLeadSec: Int get() = sp.getInt("alertLead", 60); set(v) = sp.edit().putInt("alertLead", v).apply()
    var dataSaver: Boolean get() = sp.getBoolean("dataSaver", true); set(v) = sp.edit().putBoolean("dataSaver", v).apply()
    // Calibração de cores das velas (ajustar com prints reais da plataforma)
    var upColor: Int get() = sp.getInt("upColor", 0xFF26A69A.toInt()); set(v) = sp.edit().putInt("upColor", v).apply()
    var downColor: Int get() = sp.getInt("downColor", 0xFFEF5350.toInt()); set(v) = sp.edit().putInt("downColor", v).apply()
    var colorTolerance: Int get() = sp.getInt("colorTol", 60); set(v) = sp.edit().putInt("colorTol", v).apply()
    var chartTopFrac: Float get() = sp.getFloat("chartTop", 0.18f); set(v) = sp.edit().putFloat("chartTop", v).apply()
    var chartBottomFrac: Float get() = sp.getFloat("chartBottom", 0.80f); set(v) = sp.edit().putFloat("chartBottom", v).apply()
}
