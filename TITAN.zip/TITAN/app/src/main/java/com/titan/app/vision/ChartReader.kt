package com.titan.app.vision

import android.graphics.Bitmap
import com.google.android.gms.tasks.Task
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.titan.app.avalon.AvalonEngine
import com.titan.app.avalon.TimerText
import com.titan.app.core.VisualRead
import com.titan.app.data.Settings
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

suspend fun <T> Task<T>.await(): T = suspendCancellableCoroutine { cont ->
    addOnSuccessListener { cont.resume(it) }
    addOnFailureListener { cont.resumeWithException(it) }
}

/** Lê um print: OCR (ML Kit, offline) + extração de velas. Tudo que não for lido fica null (nunca inventado). */
object ChartReader {
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    private val rxAsset = Regex("\\b([A-Z]{3})\\s?/\\s?([A-Z]{3})\\b|\\b([A-Z]{6})\\b")
    private val rxTf = Regex("\\b([MH])(1|5|15|30|60|4)\\b|\\b(1|5|15|30)\\s?(?:m|min)\\b|\\b(1|4)\\s?h\\b", RegexOption.IGNORE_CASE)
    private val rxPrice = Regex("\\b\\d{1,6}[.,]\\d{3,6}\\b")
    private val rxClock = Regex("^\\s*(\\d{1,2}):(\\d{2})\\s*$")
    private val platforms = listOf("avalon" to "Avalon", "binance" to "Binance", "tradingview" to "TradingView",
        "iq option" to "IQ Option", "quotex" to "Quotex", "olymp" to "Olymp Trade")

    suspend fun read(bmp: Bitmap, st: Settings): VisualRead {
        val notes = mutableListOf<String>()
        val text = recognizer.process(InputImage.fromBitmap(bmp, 0)).await()
        val lines = text.textBlocks.flatMap { it.lines }
        val raw = lines.map { it.text }
        val joined = raw.joinToString("\n")

        val platform = platforms.firstOrNull { joined.contains(it.first, ignoreCase = true) }?.second
        var asset: String? = null
        for (ln in raw) {
            val m = rxAsset.find(ln.uppercase()) ?: continue
            val base = if (m.groupValues[1].isNotEmpty()) "${m.groupValues[1]}/${m.groupValues[2]}" else m.groupValues[3]
            if (base == "EURUSD" || m.groupValues[1].isNotEmpty() || base.length == 6) {
                asset = base + if (ln.contains("OTC", true)) " OTC" else ""; break
            }
        }
        var tf: String? = null
        rxTf.find(joined)?.let { m ->
            tf = when {
                m.groupValues[1].isNotEmpty() -> m.groupValues[1].uppercase() + m.groupValues[2]
                m.groupValues[3].isNotEmpty() -> "M" + m.groupValues[3]
                else -> "H" + m.groupValues[4]
            }
        }
        val price = rxPrice.find(joined)?.value?.replace(',', '.')?.toDoubleOrNull()

        val h = bmp.height
        val top = (h * st.chartTopFrac).toInt(); val bot = (h * st.chartBottomFrac).toInt()
        val timers = lines.mapNotNull { ln ->
            val m = rxClock.find(ln.text) ?: return@mapNotNull null
            val sec = m.groupValues[1].toInt() * 60 + m.groupValues[2].toInt()
            TimerText(sec, ln.boundingBox?.centerY() ?: 0, ln.text)
        } + lines.filter { it.text.contains("expir", true) }.mapNotNull { ln ->
            Regex("(\\d{1,2}):(\\d{2})").find(ln.text)?.let { TimerText(it.groupValues[1].toInt() * 60 + it.groupValues[2].toInt(), -1, ln.text) }
        }
        val (candleLeft, expiry) = AvalonEngine.classifyTimers(timers, top, bot)
        if (timers.isNotEmpty()) notes += "Relógios classificados por posição/palavra-chave (heurística): confira vela x expiração."

        val (candles, cnotes) = CandleExtractor.extract(bmp, st.upColor, st.downColor, st.colorTolerance, st.chartTopFrac, st.chartBottomFrac)
        notes += cnotes
        if (platform == null) notes += "Nenhum nome de plataforma visível no print."
        return VisualRead(platform, asset, tf, if (candles.size >= 10) "Velas (candlestick)" else null,
            price, candleLeft, expiry, raw, candles, System.currentTimeMillis(), notes)
    }
}
