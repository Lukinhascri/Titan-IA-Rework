package com.titan.app.indicators

import com.titan.app.core.Candle
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Indicadores técnicos clássicos. Todas as funções devolvem arrays do mesmo tamanho da entrada,
 * com Double.NaN onde ainda não há dados suficientes (nunca valores inventados).
 */
object Indicators {
    private fun nan(n: Int) = DoubleArray(n) { Double.NaN }

    fun sma(x: DoubleArray, n: Int): DoubleArray {
        val out = nan(x.size)
        if (n <= 0 || x.size < n) return out
        var s = 0.0
        for (i in x.indices) {
            s += x[i]
            if (i >= n) s -= x[i - n]
            if (i >= n - 1) out[i] = s / n
        }
        return out
    }

    /** EMA que ignora NaN iniciais; semente = SMA das n primeiras observações válidas. */
    fun ema(x: DoubleArray, n: Int): DoubleArray {
        val out = nan(x.size)
        val first = x.indexOfFirst { !it.isNaN() }
        if (first < 0 || n <= 0 || x.size - first < n) return out
        val seedIdx = first + n - 1
        var prev = 0.0
        for (i in first..seedIdx) prev += x[i]
        prev /= n
        out[seedIdx] = prev
        val k = 2.0 / (n + 1)
        for (i in seedIdx + 1 until x.size) {
            prev = x[i] * k + prev * (1 - k)
            out[i] = prev
        }
        return out
    }

    fun rsi(c: DoubleArray, n: Int = 14): DoubleArray {
        val out = nan(c.size)
        if (c.size <= n) return out
        var gain = 0.0
        var loss = 0.0
        for (i in 1..n) {
            val d = c[i] - c[i - 1]
            if (d >= 0) gain += d else loss -= d
        }
        gain /= n; loss /= n
        out[n] = if (loss == 0.0) 100.0 else 100 - 100 / (1 + gain / loss)
        for (i in n + 1 until c.size) {
            val d = c[i] - c[i - 1]
            gain = (gain * (n - 1) + max(d, 0.0)) / n
            loss = (loss * (n - 1) + max(-d, 0.0)) / n
            out[i] = if (loss == 0.0) 100.0 else 100 - 100 / (1 + gain / loss)
        }
        return out
    }

    data class Macd(val line: DoubleArray, val signal: DoubleArray, val hist: DoubleArray)

    fun macd(c: DoubleArray, fast: Int = 12, slow: Int = 26, sig: Int = 9): Macd {
        val ef = ema(c, fast)
        val es = ema(c, slow)
        val line = DoubleArray(c.size) { if (ef[it].isNaN() || es[it].isNaN()) Double.NaN else ef[it] - es[it] }
        val signal = ema(line, sig)
        val hist = DoubleArray(c.size) { if (line[it].isNaN() || signal[it].isNaN()) Double.NaN else line[it] - signal[it] }
        return Macd(line, signal, hist)
    }

    data class Bands(val mid: DoubleArray, val upper: DoubleArray, val lower: DoubleArray)

    fun bollinger(c: DoubleArray, n: Int = 20, k: Double = 2.0): Bands {
        val mid = sma(c, n)
        val up = nan(c.size)
        val lo = nan(c.size)
        for (i in n - 1 until c.size) {
            var s = 0.0
            for (j in i - n + 1..i) s += (c[j] - mid[i]) * (c[j] - mid[i])
            val sd = sqrt(s / n)
            up[i] = mid[i] + k * sd
            lo[i] = mid[i] - k * sd
        }
        return Bands(mid, up, lo)
    }

    private fun trueRange(h: DoubleArray, l: DoubleArray, c: DoubleArray): DoubleArray =
        DoubleArray(c.size) { i ->
            if (i == 0) h[0] - l[0]
            else maxOf(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1]))
        }

    fun atr(h: DoubleArray, l: DoubleArray, c: DoubleArray, n: Int = 14): DoubleArray {
        val out = nan(c.size)
        if (c.size <= n) return out
        val tr = trueRange(h, l, c)
        var a = 0.0
        for (i in 1..n) a += tr[i]
        a /= n
        out[n] = a
        for (i in n + 1 until c.size) {
            a = (a * (n - 1) + tr[i]) / n
            out[i] = a
        }
        return out
    }

    fun adx(h: DoubleArray, l: DoubleArray, c: DoubleArray, n: Int = 14): DoubleArray {
        val sz = c.size
        val out = nan(sz)
        if (sz <= 2 * n) return out
        val tr = trueRange(h, l, c)
        val pdm = DoubleArray(sz)
        val mdm = DoubleArray(sz)
        for (i in 1 until sz) {
            val up = h[i] - h[i - 1]
            val dn = l[i - 1] - l[i]
            pdm[i] = if (up > dn && up > 0) up else 0.0
            mdm[i] = if (dn > up && dn > 0) dn else 0.0
        }
        var str = 0.0; var sp = 0.0; var sm = 0.0
        for (i in 1..n) { str += tr[i]; sp += pdm[i]; sm += mdm[i] }
        val dx = nan(sz)
        fun calcDx(i: Int) {
            val pdi = if (str == 0.0) 0.0 else 100 * sp / str
            val mdi = if (str == 0.0) 0.0 else 100 * sm / str
            dx[i] = if (pdi + mdi == 0.0) 0.0 else 100 * abs(pdi - mdi) / (pdi + mdi)
        }
        calcDx(n)
        for (i in n + 1 until sz) {
            str = str - str / n + tr[i]
            sp = sp - sp / n + pdm[i]
            sm = sm - sm / n + mdm[i]
            calcDx(i)
        }
        var a = 0.0
        for (i in n..2 * n - 1) a += dx[i]
        a /= n
        out[2 * n - 1] = a
        for (i in 2 * n until sz) {
            a = (a * (n - 1) + dx[i]) / n
            out[i] = a
        }
        return out
    }

    fun stochastic(h: DoubleArray, l: DoubleArray, c: DoubleArray, kN: Int = 14, dN: Int = 3): Pair<DoubleArray, DoubleArray> {
        val k = nan(c.size)
        for (i in kN - 1 until c.size) {
            var hh = Double.NEGATIVE_INFINITY
            var ll = Double.POSITIVE_INFINITY
            for (j in i - kN + 1..i) { hh = max(hh, h[j]); ll = min(ll, l[j]) }
            k[i] = if (hh == ll) 50.0 else 100 * (c[i] - ll) / (hh - ll)
        }
        return k to sma(k, dN)
    }

    fun cci(h: DoubleArray, l: DoubleArray, c: DoubleArray, n: Int = 20): DoubleArray {
        val tp = DoubleArray(c.size) { (h[it] + l[it] + c[it]) / 3 }
        val m = sma(tp, n)
        val out = nan(c.size)
        for (i in n - 1 until c.size) {
            var md = 0.0
            for (j in i - n + 1..i) md += abs(tp[j] - m[i])
            md /= n
            out[i] = if (md == 0.0) 0.0 else (tp[i] - m[i]) / (0.015 * md)
        }
        return out
    }

    fun obv(c: DoubleArray, v: DoubleArray): DoubleArray {
        val out = DoubleArray(c.size)
        for (i in 1 until c.size) {
            out[i] = out[i - 1] + when {
                c[i] > c[i - 1] -> v[i]
                c[i] < c[i - 1] -> -v[i]
                else -> 0.0
            }
        }
        return out
    }

    /** VWAP acumulado. Sem volume (tudo zero) devolve NaN: não inventa. */
    fun vwap(h: DoubleArray, l: DoubleArray, c: DoubleArray, v: DoubleArray): DoubleArray {
        val out = nan(c.size)
        var pv = 0.0; var vv = 0.0
        for (i in c.indices) {
            pv += (h[i] + l[i] + c[i]) / 3 * v[i]
            vv += v[i]
            out[i] = if (vv > 0) pv / vv else Double.NaN
        }
        return out
    }

    fun parabolicSar(h: DoubleArray, l: DoubleArray, step: Double = 0.02, maxAf: Double = 0.2): DoubleArray {
        val n = h.size
        val out = nan(n)
        if (n < 3) return out
        var up = h[1] >= h[0]
        var ep = if (up) h[1] else l[1]
        var sar = if (up) l[0] else h[0]
        var af = step
        out[1] = sar
        for (i in 2 until n) {
            sar += af * (ep - sar)
            if (up) {
                sar = min(sar, min(l[i - 1], l[i - 2]))
                if (l[i] < sar) { up = false; sar = ep; ep = l[i]; af = step }
                else if (h[i] > ep) { ep = h[i]; af = min(af + step, maxAf) }
            } else {
                sar = max(sar, max(h[i - 1], h[i - 2]))
                if (h[i] > sar) { up = true; sar = ep; ep = h[i]; af = step }
                else if (l[i] < ep) { ep = l[i]; af = min(af + step, maxAf) }
            }
            out[i] = sar
        }
        return out
    }

    data class Ichimoku(
        val tenkan: DoubleArray, val kijun: DoubleArray,
        val spanA: DoubleArray, val spanB: DoubleArray
    )

    /** Valores sem deslocamento (spanA/B refletem o cálculo "no índice i"; a nuvem plotada seria +26). */
    fun ichimoku(h: DoubleArray, l: DoubleArray, t: Int = 9, k: Int = 26, b: Int = 52): Ichimoku {
        fun mid(n: Int) = DoubleArray(h.size) { i ->
            if (i < n - 1) Double.NaN else {
                var hh = Double.NEGATIVE_INFINITY; var ll = Double.POSITIVE_INFINITY
                for (j in i - n + 1..i) { hh = max(hh, h[j]); ll = min(ll, l[j]) }
                (hh + ll) / 2
            }
        }
        val ten = mid(t); val kij = mid(k); val sb = mid(b)
        val sa = DoubleArray(h.size) { if (ten[it].isNaN() || kij[it].isNaN()) Double.NaN else (ten[it] + kij[it]) / 2 }
        return Ichimoku(ten, kij, sa, sb)
    }

    fun fibonacci(high: Double, low: Double, upTrend: Boolean): Map<String, Double> {
        val d = high - low
        val ratios = listOf(0.0, 0.236, 0.382, 0.5, 0.618, 0.786, 1.0)
        return ratios.associate { r ->
            String.format(java.util.Locale.US, "%.1f%%", r * 100) to (if (upTrend) high - d * r else low + d * r)
        }
    }

    data class Pivots(val p: Double, val r1: Double, val r2: Double, val s1: Double, val s2: Double)

    fun pivots(h: Double, l: Double, c: Double): Pivots {
        val p = (h + l + c) / 3
        return Pivots(p, 2 * p - l, p + (h - l), 2 * p - h, p - (h - l))
    }

    data class VolumeProfile(val low: Double, val high: Double, val bins: DoubleArray, val pocPrice: Double, val usedVolume: Boolean)

    /** Se não houver volume, usa contagem de fechamentos por faixa (TPO) e marca usedVolume=false. */
    fun volumeProfile(cs: List<Candle>, nBins: Int = 24): VolumeProfile? {
        if (cs.isEmpty()) return null
        val lo = cs.minOf { it.l }; val hi = cs.maxOf { it.h }
        if (hi <= lo) return null
        val hasVol = cs.any { it.v > 0 }
        val bins = DoubleArray(nBins)
        for (c in cs) {
            val tp = (c.h + c.l + c.c) / 3
            val idx = (((tp - lo) / (hi - lo)) * nBins).toInt().coerceIn(0, nBins - 1)
            bins[idx] += if (hasVol) c.v else 1.0
        }
        val m = bins.indices.maxByOrNull { bins[it] } ?: 0
        return VolumeProfile(lo, hi, bins, lo + (m + 0.5) * (hi - lo) / nBins, hasVol)
    }
}

fun List<Candle>.closes() = DoubleArray(size) { this[it].c }
fun List<Candle>.highs() = DoubleArray(size) { this[it].h }
fun List<Candle>.lows() = DoubleArray(size) { this[it].l }
fun List<Candle>.opens() = DoubleArray(size) { this[it].o }
fun List<Candle>.vols() = DoubleArray(size) { this[it].v }
fun DoubleArray.lastValid(): Double = lastOrNull { !it.isNaN() } ?: Double.NaN
