package com.titan.app.core

import android.os.SystemClock
import com.titan.app.TitanApp
import com.titan.app.analysis.AnalysisConfig
import com.titan.app.analysis.DecisionEngine
import com.titan.app.autotrade.PaperConfig
import com.titan.app.avalon.HybridChecker
import com.titan.app.data.Series
import com.titan.app.data.SeriesStore
import com.titan.app.vision.ChartReader
import android.graphics.Bitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Orquestra: print -> leitura -> série -> análise -> alerta -> (simulação). */
class Pipeline(private val app: TitanApp) {
    var paperConfig = PaperConfig()

    fun config() = AnalysisConfig(payout = app.settings.payout.toDouble())

    suspend fun processBitmap(bmp: Bitmap) { withContext(Dispatchers.Default) {
        TitanState.analyzing = true
        try {
            var read = ChartReader.read(bmp, app.settings)
            val asset = read.asset ?: "DESCONHECIDO"
            val tf = read.timeframe ?: "?"
            if (app.settings.mode == "HYBRID") {
                val ind = SeriesStore.get(asset, tf)?.takeIf { it.origin == DataOrigin.IMPORTADO }
                read = if (ind == null) read.copy(notes = read.notes + "Híbrido: sem série importada para $asset/$tf — comparação não realizada.")
                else read.copy(notes = read.notes + HybridChecker.compare(read.candles, ind.candles))
            }
            TitanState.lastRead = read
            if (app.settings.mode == "INDEPENDENT") {
                TitanState.say("Modo independente: leitura visual ignorada para a análise"); return@withContext
            }
            if (read.candles.isNotEmpty()) {
                // A série VISUAL é guardada separada (chave com sufixo) para não sobrescrever dados importados
                SeriesStore.put(Series(asset, tf + "·visual", DataOrigin.VISUAL, read.candles, System.currentTimeMillis()))
            }
            analyze(asset, tf, DataOrigin.VISUAL, read.candles, read)
            read.price?.let { app.trader.resolveDue(asset, it) }
        } catch (e: Exception) {
            TitanState.error = "Falha na análise: ${e.message}"
        } finally { TitanState.analyzing = false }
    } }

    /** Análise sobre qualquer série (visual, importada ou demo). */
    fun analyze(asset: String, tf: String, origin: DataOrigin, candles: List<Candle>, read: VisualRead?): Decision {
        val d = DecisionEngine.decide(asset, tf, candles, origin, read, config())
        TitanState.lastDecision = d
        TitanState.error = null
        app.db.insertAnalysis(asset, tf, origin.name, d.bias.name, d.kind.name, d.score, d.statConfidence, d.sampleSize, d.explanation)
        if (origin != DataOrigin.SINTETICO_DEMO) {
            TitanState.liveAlert = app.alerts.update(d, read, SystemClock.elapsedRealtime(), System.currentTimeMillis())
            TitanState.paperMessage = app.trader.onDecision(d, read?.price, paperConfig)
        }
        TitanState.say("Análise $asset/$tf: ${d.kind} ${d.bias}")
        return d
    }
}
