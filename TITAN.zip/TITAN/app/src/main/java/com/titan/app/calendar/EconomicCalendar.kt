package com.titan.app.calendar

import com.titan.app.data.Db
import com.titan.app.data.EventRow
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Calendário econômico. NÃO busca dados sozinho: nenhuma fonte/API autorizada foi configurada.
 * O usuário importa um CSV (de fonte confiável que ele escolher) ou cadastra eventos; a origem
 * e a data da informação ficam gravadas junto de cada evento.
 * Formato CSV: AAAA-MM-DD HH:mm; país; evento; importância(1-3); fonte; data-da-fonte
 */
class EconomicCalendar(private val db: Db) {
    fun importCsv(input: InputStream): Pair<Int, Int> {
        val f = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        var ok = 0; var bad = 0
        input.bufferedReader().useLines { lines ->
            for (ln in lines) {
                if (ln.isBlank()) continue
                val p = ln.split(';', ',').map { it.trim() }
                val t = try { f.parse(p[0])?.time } catch (_: Exception) { null }
                if (p.size < 6 || t == null) { bad++; continue }
                db.insertEvent(EventRow(0, t, p[1], p[2], p[3].toIntOrNull()?.coerceIn(1, 3) ?: 1, p[4], p[5])); ok++
            }
        }
        return ok to bad
    }

    fun upcoming(now: Long = System.currentTimeMillis()) = db.events(now - 30 * 60_000L)

    fun nearImportant(now: Long = System.currentTimeMillis(), withinMin: Int = 60): List<EventRow> =
        db.events(now).filter { it.importance >= 2 && it.time - now <= withinMin * 60_000L }

    fun impactText(importance: Int) = when (importance) {
        3 -> "Alta: costuma aumentar a volatilidade; NÃO indica a direção do mercado."
        2 -> "Média: pode aumentar a volatilidade pontualmente."
        else -> "Baixa: impacto geralmente limitado."
    }
}
