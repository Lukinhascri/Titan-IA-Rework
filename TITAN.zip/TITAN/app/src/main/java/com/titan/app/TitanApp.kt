package com.titan.app

import android.app.Application
import com.titan.app.alerts.AlertEngine
import com.titan.app.autotrade.PaperTrader
import com.titan.app.calendar.EconomicCalendar
import com.titan.app.core.Pipeline
import com.titan.app.data.Db
import com.titan.app.data.Settings
import com.titan.app.net.ConnectivityMonitor
import com.titan.app.risk.RiskManager

/** Raiz de dependências (sem framework de DI, para manter o build simples). */
class TitanApp : Application() {
    val settings by lazy { Settings(this) }
    val db by lazy { Db(this) }
    val risk by lazy { RiskManager(db, settings) }
    val trader by lazy { PaperTrader(db, settings, risk) }
    val alerts by lazy { AlertEngine(this, db) }
    val calendar by lazy { EconomicCalendar(db) }
    val net by lazy { ConnectivityMonitor(this) }
    val pipeline by lazy { Pipeline(this) }

    override fun onCreate() {
        super.onCreate()
        net.start()
    }
}
