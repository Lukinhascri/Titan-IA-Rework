package com.titan.app.core

/** Vela (candle). Para dados vindos de print, o preço é RELATIVO (escala de pixels invertida). */
data class Candle(
    val t: Long,
    val o: Double,
    val h: Double,
    val l: Double,
    val c: Double,
    val v: Double = 0.0
) {
    val body get() = kotlin.math.abs(c - o)
    val range get() = h - l
    val bullish get() = c > o
    val bearish get() = c < o
    val upperWick get() = h - maxOf(o, c)
    val lowerWick get() = minOf(o, c) - l
}

enum class Bias { ALTA, BAIXA, NEUTRO }

/** Categoria do sinal: nunca é uma previsão de certeza. */
enum class SignalKind { OPORTUNIDADE, CONFIRMACAO, AUSENCIA_DE_SINAL }

enum class DataOrigin { VISUAL, IMPORTADO, SINTETICO_DEMO }

/** Evidência individual produzida por um módulo. score em [-1, +1]. */
data class Evidence(val name: String, val score: Double, val detail: String, val weight: Double = 1.0)

data class ModuleReport(
    val module: String,
    val score: Double,          // -1..+1 (positivo = viés de alta)
    val quality: Double,        // 0..1 (qualidade dos dados para este módulo)
    val summary: String,
    val evidences: List<Evidence> = emptyList(),
    val warnings: List<String> = emptyList()
)

data class Decision(
    val asset: String,
    val timeframe: String,
    val bias: Bias,
    val kind: SignalKind,
    val score: Double,
    val statConfidence: Double?,   // null = amostra insuficiente
    val sampleSize: Int,
    val reports: List<ModuleReport>,
    val criteriaMet: List<String>,
    val criteriaMissing: List<String>,
    val explanation: String,
    val createdAt: Long = System.currentTimeMillis()
)

/** Resultado da leitura visual de um print. */
data class VisualRead(
    val platform: String?,
    val asset: String?,
    val timeframe: String?,
    val chartType: String?,
    val price: Double?,
    val candleSecondsLeft: Int?,   // tempo restante da VELA (relógio da vela)
    val expirySeconds: Int?,       // tempo de EXPIRAÇÃO configurado (diferente do anterior!)
    val rawText: List<String>,
    val candles: List<Candle>,
    val readAt: Long = System.currentTimeMillis(),
    val notes: List<String> = emptyList()
)
