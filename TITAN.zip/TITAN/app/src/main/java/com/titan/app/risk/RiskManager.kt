package com.titan.app.risk

import com.titan.app.data.Db
import com.titan.app.data.Settings
import java.util.Calendar

data class RiskStatus(val allowed: Boolean, val reasons: List<String>, val lossToday: Double, val opsToday: Int, val lossStreak: Int)

/** Proteção de capital (somente sobre operações SIMULADAS). Nunca altera os limites do usuário. */
class RiskManager(private val db: Db, private val settings: Settings) {
    private fun startOfDay(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    fun status(): RiskStatus {
        val sod = startOfDay()
        val today = db.trades(source = "SIM").filter { it.openedAt >= sod }
        val ops = today.size
        val loss = -today.filter { it.closedAt != null }.sumOf { minOf(0.0, it.pl ?: 0.0) }
        val net = today.filter { it.closedAt != null }.sumOf { it.pl ?: 0.0 }
        var streak = 0
        for (t in db.trades(source = "SIM", onlyClosed = true)) { if (t.result == "LOSS") streak++ else break }
        val r = mutableListOf<String>()
        if (settings.emergencyStop) r += "BOTÃO DE EMERGÊNCIA ativo"
        if (net < 0 && -net >= settings.maxLossDay) r += "Limite de perda diária atingido (${"%.2f".format(-net)} ≥ ${settings.maxLossDay})"
        if (ops >= settings.maxOpsDay) r += "Limite de operações simuladas do dia atingido ($ops)"
        if (streak >= settings.pauseAfterLosses) r += "Pausa após $streak perdas seguidas"
        return RiskStatus(r.isEmpty(), r, loss, ops, streak)
    }

    fun emergency(on: Boolean) {
        settings.emergencyStop = on
        db.log("USUÁRIO", if (on) "EMERGÊNCIA_ON" else "EMERGÊNCIA_OFF", "Botão de emergência alterado pelo usuário")
    }

    fun changeLimit(name: String, old: String, new: String) =
        db.log("USUÁRIO", "LIMITE_ALTERADO", "$name: $old -> $new")
}
