package com.titan.app.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.titan.app.TitanApp
import com.titan.app.autotrade.PaperConfig
import com.titan.app.copilot.Copilot
import com.titan.app.core.*
import com.titan.app.data.SeriesStore
import com.titan.app.lab.BtConfig
import com.titan.app.lab.BtResult
import com.titan.app.lab.Backtester
import com.titan.app.strategies.Strategies
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun fmtTime(t: Long) = SimpleDateFormat("dd/MM HH:mm:ss", Locale.getDefault()).format(Date(t))

// ============ 5. AUTO TRADE (SOMENTE SIMULAÇÃO) ============
@Composable
fun AutoTradeScreen(app: TitanApp) {
    var tick by remember { mutableStateOf(0) }
    var running by remember { mutableStateOf(app.trader.running) }
    var requireConfirm by remember { mutableStateOf(app.pipeline.paperConfig.requireKind == SignalKind.CONFIRMACAO) }
    var expiry by remember { mutableStateOf(app.pipeline.paperConfig.expirySec.toString()) }
    var closePrice by remember { mutableStateOf("") }
    val risk = remember(tick, TitanState.paperMessage) { app.risk.status() }
    val trades = remember(tick, TitanState.paperMessage) { app.db.trades(source = "SIM") }
    Page {
        TCard("Auto Trade — SOMENTE SIMULAÇÃO (paper trading)") {
            Warn("Nenhuma ordem real é enviada. O TITAN não pede, guarda nem usa senha de corretora.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TButton(if (running) "Simulação ATIVA" else "Iniciar simulação", { app.trader.start(); running = true }, Modifier.weight(1f), enabled = !running)
                TOutline("Encerrar", { app.trader.stop(); running = false }, Modifier.weight(1f))
            }
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Switch(checked = requireConfirm, onCheckedChange = {
                    requireConfirm = it
                    app.pipeline.paperConfig = app.pipeline.paperConfig.copy(requireKind = if (it) SignalKind.CONFIRMACAO else SignalKind.OPORTUNIDADE)
                })
                Spacer(Modifier.width(8.dp)); Text(if (requireConfirm) "Entrar só em CONFIRMAÇÃO" else "Entrar em OPORTUNIDADE ou CONFIRMAÇÃO", fontSize = 13.sp)
            }
            TField(expiry, { expiry = it.filter(Char::isDigit); expiry.toIntOrNull()?.let { s -> app.pipeline.paperConfig = app.pipeline.paperConfig.copy(expirySec = s.coerceIn(5, 3600)) } }, "Expiração simulada (segundos)")
            Muted("Entrada simulada = preço lido na tela no momento da decisão; saída = preço lido após a expiração. Sem preço lido, nada é aberto.")
            if (TitanState.paperMessage.isNotEmpty()) Muted("Último evento: ${TitanState.paperMessage}")
        }
        TCard("Proteção de capital (simulado)") {
            KV("Perda do dia", "%.2f / limite %.2f".format(risk.lossToday, app.settings.maxLossDay))
            KV("Operações hoje", "${risk.opsToday} / ${app.settings.maxOpsDay}")
            KV("Perdas seguidas", "${risk.lossStreak} / pausa em ${app.settings.pauseAfterLosses}")
            Pill(if (risk.allowed) "OPERAÇÕES PERMITIDAS" else "BLOQUEADO", if (risk.allowed) TitanColors.Green else TitanColors.Red)
            risk.reasons.forEach { Warn(it) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { app.risk.emergency(true); tick++ }, colors = ButtonDefaults.buttonColors(containerColor = TitanColors.Red), modifier = Modifier.weight(1f)) { Text("EMERGÊNCIA", fontSize = 13.sp) }
                TOutline("Liberar", { app.risk.emergency(false); tick++ }, Modifier.weight(1f))
            }
            Muted("Limites são definidos por você em Configurações; o TITAN nunca os altera sozinho.")
        }
        TCard("Teste manual da simulação") {
            Muted("Use para validar o fluxo sem captura: fecha operações abertas vencidas usando o preço informado.")
            TField(closePrice, { closePrice = it }, "Preço atual (para resolver abertas)")
            TButton("Resolver operações vencidas", {
                val p = closePrice.replace(',', '.').toDoubleOrNull() ?: return@TButton
                trades.filter { it.closedAt == null }.map { it.asset }.distinct().forEach { app.trader.resolveDue(it, p) }
                tick++
            })
        }
        TCard("Operações simuladas") {
            if (trades.isEmpty()) Muted("Nenhuma operação simulada.")
            trades.take(30).forEach { t ->
                KV("${fmtTime(t.openedAt)} ${t.asset} ${if (t.direction > 0) "▲" else "▼"}", (t.result ?: "ABERTA") + (t.pl?.let { " ${"%.2f".format(it)}" } ?: ""))
            }
        }
    }
}

// ============ 6. COPILOT ============
@Composable
fun CopilotScreen() {
    var q by remember { mutableStateOf("") }
    val chat = remember { mutableStateListOf("TITAN Copilot" to "Olá! Explico indicadores, padrões, alertas e o cenário atual usando só dados do app. Digite 'ajuda'.") }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        LazyColumn(Modifier.weight(1f)) {
            items(chat.toList()) { (who, msg) ->
                TCard(who) { Text(msg, fontSize = 13.sp) }
            }
        }
        Spacer(Modifier.height(6.dp))
        TField(q, { q = it }, "Pergunte ao Copilot")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
            TButton("Enviar", { if (q.isNotBlank()) { chat.add("Você" to q); chat.add("TITAN Copilot" to Copilot.answer(q)); q = "" } }, Modifier.weight(1f))
            TOutline("Resumo", { chat.add("TITAN Copilot" to Copilot.answer("resumo do cenário")) }, Modifier.weight(1f))
            TOutline("Por que o alerta?", { chat.add("TITAN Copilot" to Copilot.answer("por que o alerta")) }, Modifier.weight(1f))
        }
    }
}

// ============ 7. CALENDÁRIO ECONÔMICO ============
@Composable
fun CalendarScreen(app: TitanApp, a: Actions) {
    var tick by remember { mutableStateOf(0) }
    val events = remember(tick, UiBus.message) { app.calendar.upcoming() }
    val near = remember(tick, UiBus.message) { app.calendar.nearImportant() }
    var date by remember { mutableStateOf("") }; var country by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }; var imp by remember { mutableStateOf("2") }
    var source by remember { mutableStateOf("") }; var srcDate by remember { mutableStateOf("") }
    Page {
        if (near.isNotEmpty()) TCard("Eventos importantes próximos (60 min)") {
            near.forEach { Warn("${fmtTime(it.time)} ${it.country} ${it.title} — ${app.calendar.impactText(it.importance)}") }
            Muted("Um evento pode aumentar a volatilidade; ele não determina a direção do mercado.")
        }
        TCard("Fonte dos dados") {
            Warn("O TITAN não busca calendário sozinho: nenhuma fonte/API autorizada está configurada. Importe um CSV de uma fonte confiável escolhida por você.")
            Muted("Formato: AAAA-MM-DD HH:mm;país;evento;importância 1-3;fonte;data da fonte")
            TButton("Importar CSV do calendário", a.pickCalendarCsv)
            if (UiBus.message.isNotEmpty()) Muted(UiBus.message)
        }
        TCard("Adicionar evento manualmente") {
            TField(date, { date = it }, "Data/hora (AAAA-MM-DD HH:mm)"); TField(country, { country = it }, "País")
            TField(title, { title = it }, "Evento"); TField(imp, { imp = it.filter(Char::isDigit) }, "Importância (1-3)")
            TField(source, { source = it }, "Fonte (nome)"); TField(srcDate, { srcDate = it }, "Data da informação na fonte")
            TButton("Salvar evento", {
                val t = try { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).parse(date)?.time } catch (_: Exception) { null }
                if (t != null && title.isNotBlank() && source.isNotBlank()) {
                    app.db.insertEvent(com.titan.app.data.EventRow(0, t, country, title, imp.toIntOrNull()?.coerceIn(1, 3) ?: 1, source, srcDate)); tick++
                    title = ""; UiBus.message = "Evento salvo."
                } else UiBus.message = "Preencha data válida, evento e fonte."
            })
        }
        TCard("Próximos eventos") {
            if (events.isEmpty()) Muted("Nenhum evento cadastrado.")
            events.take(40).forEach { e ->
                Text("${fmtTime(e.time)} · ${e.country} · ${e.title}", fontSize = 13.sp)
                Muted("Importância ${e.importance}/3 · ${app.calendar.impactText(e.importance)} · Fonte: ${e.sourceName} (${e.sourceDate})")
            }
        }
    }
}

// ============ 8. TITAN LAB ============
@Composable
fun LabScreen(app: TitanApp) {
    val scope = rememberCoroutineScope()
    var expiry by remember { mutableStateOf("1") }; var cost by remember { mutableStateOf("0") }
    var results by remember { mutableStateOf<List<BtResult>>(emptyList()) }
    var oos by remember { mutableStateOf<List<BtResult>>(emptyList()) }
    var wf by remember { mutableStateOf<List<BtResult>>(emptyList()) }
    var stratId by remember { mutableStateOf(Strategies.all.first().id) }
    var busy by remember { mutableStateOf(false) }
    val sel = UiBus.selectedKey?.let { SeriesStore.map[it] }
    Page {
        TCard("TITAN Lab — backtesting") {
            Muted("Série: " + (sel?.let { "${it.asset} ${it.timeframe} (${it.origin}, ${it.candles.size} velas)" } ?: "selecione na aba Análise"))
            Muted("Regra anti-vazamento: sinal no fechamento da vela i, entrada na abertura de i+1, saída no fechamento de i+expiração.")
            TField(expiry, { expiry = it.filter(Char::isDigit) }, "Expiração (em velas)"); TField(cost, { cost = it }, "Custo/slippage estimado (% do valor por operação)")
            Muted("Payout e valor por operação vêm das Configurações.")
            Muted("Estratégia para OOS/walk-forward:")
            Strategies.all.chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    row.forEach { s -> FilterChip(selected = stratId == s.id, onClick = { stratId = s.id }, label = { Text(s.name, fontSize = 11.sp) }) }
                }
            }
            TButton(if (busy) "Rodando…" else "Rodar laboratório", {
                val s = sel ?: return@TButton
                busy = true
                scope.launch {
                    withContext(Dispatchers.Default) {
                        val cfg = BtConfig(expiry.toIntOrNull()?.coerceIn(1, 30) ?: 1, app.settings.stake.toDouble(), app.settings.payout.toDouble(),
                            (cost.replace(',', '.').toDoubleOrNull() ?: 0.0) / 100.0)
                        results = Strategies.all.map { Backtester.run(s.candles, it, cfg) }.sortedByDescending { it.expectancy }
                        val st = Strategies.byId(stratId)!!
                        oos = Backtester.outOfSample(s.candles, st, cfg).toList()
                        wf = Backtester.walkForward(s.candles, st, cfg)
                    }
                    busy = false
                }
            }, enabled = sel != null && !busy)
            if (sel?.origin == DataOrigin.SINTETICO_DEMO) Warn("Série SINTÉTICA: resultados servem só para testar o app.")
        }
        if (results.isNotEmpty()) {
            Warn(Backtester.DISCLAIMER)
            TCard("Comparação de estratégias (amostra completa)") { results.forEach { ResultRow(it) } }
            TCard("Dentro x fora da amostra") { oos.forEach { ResultRow(it) }; Muted("Se o desempenho cai muito fora da amostra, suspeite de overfitting.") }
            TCard("Walk-forward (janelas consecutivas)") {
                wf.forEach { ResultRow(it) }
                val rates = wf.filter { it.wins + it.losses > 0 }.map { it.winRate }
                if (rates.size > 1) Muted("Variação da taxa de acerto entre janelas: ${"%.0f".format((rates.max() - rates.min()) * 100)} p.p. (quanto maior, menos estável).")
            }
        }
    }
}

@Composable
private fun ResultRow(r: BtResult) {
    Text("${r.strategy} · ${r.segment}", fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold, fontSize = 13.sp)
    Muted("${r.trades} trades (${r.wins}V/${r.losses}D/${r.ties}E) · acerto ${"%.1f".format(r.winRate * 100)}% (IC95% ${"%.0f".format(r.wilsonLow * 100)}–${"%.0f".format(r.wilsonHigh * 100)}%) · equilíbrio ${"%.1f".format(r.breakEven * 100)}%")
    Muted("P/L ${"%.2f".format(r.netPl)} · expectativa/op ${"%.2f".format(r.expectancy)} · drawdown máx ${"%.2f".format(r.maxDrawdown)} · fator de lucro ${if (r.profitFactor.isInfinite()) "∞" else "%.2f".format(r.profitFactor)} · falsos sinais ${r.falseSignals} · pior sequência ${r.longestLossStreak}")
    Muted(if (r.edgeProven) "Vantagem estatística acima do equilíbrio nesta amostra." else if (r.trades < 30) "Amostra pequena: sem conclusão." else "Sem vantagem comprovada sobre o equilíbrio.")
}

// ============ 9. HISTÓRICO ============
@Composable
fun HistoryScreen(app: TitanApp, a: Actions) {
    val analyses = remember(TitanState.lastDecision, UiBus.message) { app.db.recentAnalyses(40) }
    val alerts = remember(TitanState.liveAlert, TitanState.lastDecision) { app.db.alerts(40) }
    val audit = remember(TitanState.paperMessage, UiBus.message, TitanState.lastDecision) { app.db.auditLog(40) }
    Page {
        TCard("Importar operações REAIS (CSV)") {
            Muted("Formato (separador ;): AAAA-MM-DD HH:mm;ativo;tempo;estratégia;direção 1/-1;entrada;saída;valor;WIN|LOSS|TIE;lucro")
            Muted("Ficam separadas das simuladas (origem IMPORT).")
            TButton("Importar CSV de operações", a.pickTradesCsv)
            if (UiBus.message.isNotEmpty()) Muted(UiBus.message)
        }
        TCard("Histórico de análises/sinais") {
            if (analyses.isEmpty()) Muted("Sem análises.")
            analyses.forEach { Muted("${fmtTime(it[0].toLong())} · ${it[1]} ${it[2]} · ${it[3]} · ${it[4]} ${it[5]}") }
        }
        TCard("Alertas emitidos") {
            if (alerts.isEmpty()) Muted("Sem alertas.")
            alerts.forEach { Muted("${fmtTime(it.createdAt)} · ${it.asset} · ${it.kind} ${it.bias} · ${it.status}") }
        }
        TCard("Registro de decisões e alterações") {
            if (audit.isEmpty()) Muted("Sem registros.")
            audit.forEach { Muted("${fmtTime(it[0].toLong())} · ${it[1]} · ${it[2]} · ${it[3]}") }
        }
    }
}

// ============ 10. CONFIGURAÇÕES ============
@Composable
fun SettingsScreen(app: TitanApp) {
    val s = app.settings
    var payout by remember { mutableStateOf((s.payout * 100).toInt().toString()) }
    var stake by remember { mutableStateOf(s.stake.toString()) }
    var maxLoss by remember { mutableStateOf(s.maxLossDay.toString()) }
    var maxOps by remember { mutableStateOf(s.maxOpsDay.toString()) }
    var pause by remember { mutableStateOf(s.pauseAfterLosses.toString()) }
    var interval by remember { mutableStateOf(s.captureIntervalSec.toString()) }
    var saver by remember { mutableStateOf(s.dataSaver) }
    var top by remember { mutableStateOf(s.chartTopFrac) }; var bot by remember { mutableStateOf(s.chartBottomFrac) }
    var tol by remember { mutableStateOf(s.colorTolerance.toFloat()) }
    var pick by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf("") }
    Page {
        TCard("Risco e simulação (somente você altera)") {
            TField(payout, { payout = it.filter(Char::isDigit) }, "Payout líquido (%)")
            TField(stake, { stake = it }, "Valor por operação simulada")
            TField(maxLoss, { maxLoss = it }, "Limite de perda diária (simulada)")
            TField(maxOps, { maxOps = it.filter(Char::isDigit) }, "Limite de operações simuladas por dia")
            TField(pause, { pause = it.filter(Char::isDigit) }, "Pausar após N perdas seguidas")
            TButton("Salvar limites", {
                fun chg(n: String, o: String, nw: String) { if (o != nw) app.risk.changeLimit(n, o, nw) }
                chg("payout%", (s.payout * 100).toInt().toString(), payout); chg("valor", s.stake.toString(), stake)
                chg("perda diária", s.maxLossDay.toString(), maxLoss); chg("ops/dia", s.maxOpsDay.toString(), maxOps); chg("pausa", s.pauseAfterLosses.toString(), pause)
                s.payout = (payout.toFloatOrNull() ?: 80f).coerceIn(1f, 500f) / 100f
                s.stake = stake.replace(',', '.').toFloatOrNull() ?: s.stake
                s.maxLossDay = maxLoss.replace(',', '.').toFloatOrNull() ?: s.maxLossDay
                s.maxOpsDay = maxOps.toIntOrNull() ?: s.maxOpsDay; s.pauseAfterLosses = pause.toIntOrNull() ?: s.pauseAfterLosses
                saved = "Salvo e registrado no log de auditoria."
            })
            if (saved.isNotEmpty()) Muted(saved)
        }
        TCard("Captura e dados") {
            TField(interval, { interval = it.filter(Char::isDigit); interval.toIntOrNull()?.let { v -> s.captureIntervalSec = v.coerceIn(2, 120) } }, "Intervalo da captura (segundos, mín. 2)")
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Switch(checked = saver, onCheckedChange = { saver = it; s.dataSaver = it }); Spacer(Modifier.width(8.dp))
                Text("Economia de dados (rede só para medir latência)", fontSize = 13.sp)
            }
            Muted("A análise e o OCR rodam no aparelho (offline). O app só usa internet para medir latência de conexão.")
        }
        TCard("Calibração visual (cores e região do gráfico)") {
            Muted("1) Capture a tela com o gráfico aberto. 2) Escolha ALTA/BAIXA e toque numa vela da imagem. 3) Ajuste a região vertical do gráfico.")
            val bmp = TitanState.lastBitmap
            if (bmp == null) Muted("Sem print capturado ainda.") else CalibrationImage(bmp, top, bot, pick) { color ->
                if (pick == "UP") { s.upColor = color } else if (pick == "DOWN") { s.downColor = color }
                saved = "Cor ${if (pick == "UP") "de alta" else "de baixa"} definida: #%06X".format(color and 0xFFFFFF)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = pick == "UP", onClick = { pick = "UP" }, label = { Text("Cor ALTA") })
                FilterChip(selected = pick == "DOWN", onClick = { pick = "DOWN" }, label = { Text("Cor BAIXA") })
            }
            Muted("Topo da região: ${(top * 100).toInt()}%"); Slider(value = top, onValueChange = { top = it; s.chartTopFrac = it }, valueRange = 0f..0.6f)
            Muted("Base da região: ${(bot * 100).toInt()}%"); Slider(value = bot, onValueChange = { bot = it; s.chartBottomFrac = it }, valueRange = 0.4f..1f)
            Muted("Tolerância de cor: ${tol.toInt()}"); Slider(value = tol, onValueChange = { tol = it; s.colorTolerance = it.toInt() }, valueRange = 20f..120f)
        }
        TCard("Sobre") {
            KV("Versão", "1.0.0"); KV("Compatibilidade", "Android 8.0+ (API 26)")
            Muted("Redes: Wi-Fi, 4G, 5G e qualquer operadora (Vivo, Claro, TIM, Algar...): o app só precisa de internet.")
            Muted("TITAN é ferramenta de apoio e não garante resultados.")
        }
    }
}

@Composable
private fun CalibrationImage(bmp: Bitmap, top: Float, bot: Float, pick: String, onColor: (Int) -> Unit) {
    var size by remember { mutableStateOf(IntSize(1, 1)) }
    val img = remember(bmp) { bmp.asImageBitmap() }
    Box(Modifier.fillMaxWidth().height(260.dp).onSizeChanged { size = it }.pointerInput(bmp, pick) {
        detectTapGestures { off ->
            if (pick.isEmpty()) return@detectTapGestures
            val scale = minOf(size.width.toFloat() / bmp.width, size.height.toFloat() / bmp.height)
            val dw = bmp.width * scale; val dh = bmp.height * scale
            val ox = (size.width - dw) / 2; val oy = (size.height - dh) / 2
            val x = ((off.x - ox) / scale).toInt(); val y = ((off.y - oy) / scale).toInt()
            if (x in 0 until bmp.width && y in 0 until bmp.height) onColor(bmp.getPixel(x, y))
        }
    }) {
        Image(bitmap = img, contentDescription = "Último print", modifier = Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Fit)
        Canvas(Modifier.fillMaxSize()) {
            val scale = minOf(size.width / bmp.width, size.height / bmp.height)
            val dh = bmp.height * scale; val oy = (size.height - dh) / 2
            val c = androidx.compose.ui.graphics.Color(0xAA22D3EE)
            drawLine(c, androidx.compose.ui.geometry.Offset(0f, oy + dh * top), androidx.compose.ui.geometry.Offset(size.width, oy + dh * top), 3f)
            drawLine(c, androidx.compose.ui.geometry.Offset(0f, oy + dh * bot), androidx.compose.ui.geometry.Offset(size.width, oy + dh * bot), 3f)
        }
    }
}
