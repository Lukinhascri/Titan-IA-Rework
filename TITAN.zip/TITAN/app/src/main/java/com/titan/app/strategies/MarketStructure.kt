package com.titan.app.strategies

import com.titan.app.core.Bias
import com.titan.app.core.Candle
import com.titan.app.patterns.ChartPatterns

data class StructureReport(
    val trend: Bias,
    val description: String,
    val bos: String?,            // Break of Structure
    val liquiditySweep: String?, // varredura de liquidez (conceito SMC/ICT)
    val fairValueGaps: Int,      // FVGs abertos nas últimas velas
    val supports: List<Double>,
    val resistances: List<Double>
)

/**
 * Teoria de Dow + conceitos objetivos de SMC/ICT (BOS, sweep, FVG).
 * NÃO implementados (por não serem objetivos o bastante para automatizar com honestidade):
 * contagem de Ondas de Elliott e fases de Wyckoff. Estão listados como limitação no README.
 */
object MarketStructure {
    fun analyze(cs: List<Candle>): StructureReport {
        val sw = ChartPatterns.swings(cs)
        val highs = sw.filter { it.isHigh }
        val lows = sw.filter { !it.isHigh }
        if (highs.size < 2 || lows.size < 2) {
            return StructureReport(Bias.NEUTRO, "Swings insuficientes para definir estrutura", null, null, 0,
                lows.map { it.price }, highs.map { it.price })
        }
        val hh = highs.last().price > highs[highs.size - 2].price
        val hl = lows.last().price > lows[lows.size - 2].price
        val trend = when {
            hh && hl -> Bias.ALTA
            !hh && !hl -> Bias.BAIXA
            else -> Bias.NEUTRO
        }
        val desc = when {
            hh && hl -> "Topos e fundos ascendentes (Dow: tendência de alta)"
            !hh && !hl -> "Topos e fundos descendentes (Dow: tendência de baixa)"
            else -> "Estrutura mista (sem confirmação de Dow)"
        }
        val last = cs.last()
        var bos: String? = null
        if (last.c > highs.last().price) bos = "BOS de alta: fechamento acima do último topo"
        if (last.c < lows.last().price) bos = "BOS de baixa: fechamento abaixo do último fundo"
        var sweep: String? = null
        val rec = cs.takeLast(3)
        if (rec.any { it.h > highs.last().price } && last.c < highs.last().price) sweep = "Varredura de liquidez acima do topo, fechamento de volta abaixo"
        if (rec.any { it.l < lows.last().price } && last.c > lows.last().price) sweep = "Varredura de liquidez abaixo do fundo, fechamento de volta acima"
        // FVG: vela1.high < vela3.low (alta) ou vela1.low > vela3.high (baixa), ainda não preenchido
        var fvg = 0
        val from = maxOf(0, cs.size - 20)
        for (i in from + 2 until cs.size) {
            val a = cs[i - 2]; val c3 = cs[i]
            if (a.h < c3.l && cs.subList(i + 1, cs.size).none { it.l <= a.h }) fvg++
            if (a.l > c3.h && cs.subList(i + 1, cs.size).none { it.h >= a.l }) fvg++
        }
        return StructureReport(trend, desc, bos, sweep, fvg,
            lows.takeLast(3).map { it.price }, highs.takeLast(3).map { it.price })
    }
}
