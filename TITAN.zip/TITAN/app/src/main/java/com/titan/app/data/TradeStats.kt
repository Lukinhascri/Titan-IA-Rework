package com.titan.app.data

import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

data class Group(val key: String, val trades: Int, val wins: Int, val losses: Int, val ties: Int, val pl: Double) {
    val winRate get() = if (wins + losses == 0) 0.0 else wins.toDouble() / (wins + losses)
}

data class Summary(
    val total: Int, val wins: Int, val losses: Int, val ties: Int, val pl: Double, val winRate: Double,
    val longestWin: Int, val longestLoss: Int, val byAsset: List<Group>, val byStrategy: List<Group>,
    val byTimeframe: List<Group>, val byDay: List<Group>, val byWeek: List<Group>, val byMonth: List<Group>
)

/** Estatísticas calculadas SOMENTE a partir de operações fechadas gravadas no banco. Nada é inventado. */
object TradeStats {
    private fun group(ts: List<SimTrade>, keyOf: (SimTrade) -> String): List<Group> =
        ts.groupBy(keyOf).map { (k, v) ->
            Group(k, v.size, v.count { it.result == "WIN" }, v.count { it.result == "LOSS" }, v.count { it.result == "TIE" }, v.sumOf { it.pl ?: 0.0 })
        }.sortedBy { it.key }

    fun summarize(all: List<SimTrade>): Summary {
        val ts = all.filter { it.closedAt != null }
        val w = ts.count { it.result == "WIN" }; val l = ts.count { it.result == "LOSS" }; val t = ts.count { it.result == "TIE" }
        var bw = 0; var bl = 0; var cw = 0; var cl = 0
        for (x in ts.sortedBy { it.closedAt }) {
            when (x.result) {
                "WIN" -> { cw++; cl = 0 }
                "LOSS" -> { cl++; cw = 0 }
                else -> { cw = 0; cl = 0 }
            }
            bw = maxOf(bw, cw); bl = maxOf(bl, cl)
        }
        val dayF = SimpleDateFormat("yyyy-MM-dd", Locale.US); val monF = SimpleDateFormat("yyyy-MM", Locale.US)
        fun week(t: SimTrade): String = Calendar.getInstance().apply { timeInMillis = t.closedAt!! }.let { "${it.get(Calendar.YEAR)}-S%02d".format(it.get(Calendar.WEEK_OF_YEAR)) }
        return Summary(ts.size, w, l, t, ts.sumOf { it.pl ?: 0.0 }, if (w + l == 0) 0.0 else w.toDouble() / (w + l), bw, bl,
            group(ts) { it.asset }, group(ts) { it.strategy }, group(ts) { it.timeframe },
            group(ts) { dayF.format(it.closedAt!!) }, group(ts, ::week), group(ts) { monF.format(it.closedAt!!) })
    }

    /** CSV de operações REAIS importadas pelo usuário: AAAA-MM-DD HH:mm;ativo;tempo;estrategia;direcao(1/-1);entrada;saida;stake;WIN|LOSS|TIE;lucro */
    fun importTrades(db: Db, input: InputStream): Pair<Int, Int> {
        val f = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        var ok = 0; var bad = 0
        input.bufferedReader().useLines { lines ->
            for (ln in lines) {
                if (ln.isBlank()) continue
                val p = ln.split(';').map { it.trim() }
                val t = try { f.parse(p[0])?.time } catch (_: Exception) { null }
                val res = p.getOrNull(8)?.uppercase() ?: ""
                if (p.size < 10 || t == null || res !in listOf("WIN", "LOSS", "TIE")) { bad++; continue }
                db.insertTrade(SimTrade(0, t, t, p[1], p[2], p[3], p[4].toIntOrNull() ?: 0, p[5].toDoubleOrNull() ?: 0.0,
                    p[6].toDoubleOrNull(), p[7].toDoubleOrNull() ?: 0.0, 0.0, 0, res, p[9].toDoubleOrNull() ?: 0.0, "IMPORT")); ok++
            }
        }
        return ok to bad
    }
}
