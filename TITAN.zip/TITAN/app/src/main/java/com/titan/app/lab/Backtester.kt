package com.titan.app.lab

import com.titan.app.analysis.Stats
import com.titan.app.core.Candle
import com.titan.app.strategies.Strategy
import kotlin.math.abs

data class BtConfig(
    val expiryCandles: Int = 1,
    val stake: Double = 10.0,
    val payout: Double = 0.80,
    val costPct: Double = 0.0,        // custo/slippage estimado como fração do stake por operação
    val minGap: Int = 1               // evita sinais sobrepostos (nova operação só após a anterior expirar)
)

data class BtResult(
    val strategy: String, val segment: String, val trades: Int, val wins: Int, val losses: Int, val ties: Int,
    val winRate: Double, val wilsonLow: Double, val wilsonHigh: Double, val breakEven: Double,
    val netPl: Double, val expectancy: Double, val maxDrawdown: Double, val profitFactor: Double,
    val falseSignals: Int, val longestLossStreak: Int
) {
    val edgeProven get() = trades >= 30 && wilsonLow > breakEven
}

object Backtester {
    /**
     * Regra anti-vazamento: sinal calculado no FECHAMENTO da vela i; entrada na ABERTURA da vela i+1;
     * saída no fechamento da vela i+expiry. Nenhum dado futuro entra no sinal.
     */
    fun run(cs: List<Candle>, s: Strategy, cfg: BtConfig, from: Int = 0, to: Int = cs.size, label: String = "completo"): BtResult {
        val sig = s.signals(cs)
        var w = 0; var l = 0; var t = 0; var net = 0.0; var peak = 0.0; var dd = 0.0; var gp = 0.0; var gl = 0.0
        var streak = 0; var maxStreak = 0
        var i = maxOf(from, 0)
        val last = minOf(to, cs.size) - 1 - cfg.expiryCandles
        while (i <= last) {
            val d = sig[i]
            if (d == 0) { i++; continue }
            val entry = cs[i + 1].o
            val exit = cs[i + cfg.expiryCandles].c
            val pl = when {
                abs(exit - entry) < 1e-12 -> { t++; streak = 0; 0.0 }
                (exit > entry) == (d > 0) -> { w++; streak = 0; cfg.stake * cfg.payout - cfg.stake * cfg.costPct }
                else -> { l++; streak++; maxStreak = maxOf(maxStreak, streak); -cfg.stake - cfg.stake * cfg.costPct }
            }
            net += pl; if (pl > 0) gp += pl else gl += -pl
            peak = maxOf(peak, net); dd = maxOf(dd, peak - net)
            i += maxOf(cfg.minGap, 1) + cfg.expiryCandles - 1
        }
        val n = w + l + t
        val dec = w + l
        val wr = if (dec == 0) 0.0 else w.toDouble() / dec
        val (lo, hi) = Stats.wilson(w, dec)
        return BtResult(s.name, label, n, w, l, t, wr, lo, hi, Stats.breakEven(cfg.payout), net,
            if (n == 0) 0.0 else net / n, dd, if (gl == 0.0) (if (gp > 0) Double.POSITIVE_INFINITY else 0.0) else gp / gl, l, maxStreak)
    }

    /** Teste fora da amostra: "treino" 70% / "teste" 30%, sem reotimizar nada com os dados de teste. */
    fun outOfSample(cs: List<Candle>, s: Strategy, cfg: BtConfig): Pair<BtResult, BtResult> {
        val cut = (cs.size * 0.7).toInt()
        return run(cs, s, cfg, 0, cut, "dentro da amostra (70%)") to run(cs, s, cfg, cut, cs.size, "FORA da amostra (30%)")
    }

    /** Walk-forward: janelas consecutivas e disjuntas; mede a estabilidade da taxa de acerto entre janelas. */
    fun walkForward(cs: List<Candle>, s: Strategy, cfg: BtConfig, windows: Int = 5): List<BtResult> {
        val size = cs.size / windows
        return (0 until windows).map { k -> run(cs, s, cfg, k * size, if (k == windows - 1) cs.size else (k + 1) * size, "janela ${k + 1}/$windows") }
    }

    const val DISCLAIMER = "Resultados históricos NÃO representam desempenho futuro. Poucos trades = alta incerteza; " +
        "testar muitas estratégias nos mesmos dados aumenta o risco de overfitting (acertos por sorte)."
}
