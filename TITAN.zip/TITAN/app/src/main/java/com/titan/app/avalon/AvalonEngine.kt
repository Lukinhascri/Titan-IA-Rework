package com.titan.app.avalon

import com.titan.app.core.Candle
import com.titan.app.core.VisualRead
import kotlin.math.abs

data class AvalonAssessment(
    val platformDetected: Boolean,
    val integrationMode: String,
    val limitations: List<String>
)

/**
 * TITAN AVALON ENGINE.
 *
 * STATUS DA INTEGRAÇÃO (verdade técnica): em uma busca inicial NÃO foi encontrada documentação oficial
 * nem API pública autorizada da Avalon (site usado pelo usuário: trade.avalonbroker.com, via Chrome).
 * Portanto NÃO existe integração por API neste código. O caminho implementado é:
 *   1) Modo visual: leitura autorizada da tela (MediaProjection + OCR + extração de velas);
 *   2) Modo independente: dados importados pelo usuário (CSV) — não vêm da Avalon automaticamente;
 *   3) Modo híbrido: compara (1) e (2) e sinaliza inconsistências.
 * Se a Avalon publicar uma API oficial, implemente a interface [AvalonDataSource] e registre-a em Pipeline.
 */
object AvalonEngine {
    const val KNOWN_SITE = "trade.avalonbroker.com"
    const val OFFICIAL_API_FOUND = false

    fun assess(read: VisualRead?): AvalonAssessment {
        val lim = mutableListOf(
            "Sem API oficial conhecida: preço e velas vêm do que está visível na tela.",
            "Preços lidos de print são RELATIVOS (escala em pixels) até haver calibração com o eixo de preço.",
            "Lista de ativos da Avalon não é acessível: o Radar usa apenas ativos já vistos/importados.",
            "Cores das velas e posição do gráfico precisam ser calibradas com prints reais (Configurações > Calibração)."
        )
        val detected = read?.platform?.contains("avalon", ignoreCase = true) == true
        if (read != null && !detected) lim += "Plataforma Avalon NÃO foi reconhecida no print (nome não apareceu no texto lido)."
        return AvalonAssessment(detected, "VISUAL_AUTORIZADO", lim)
    }

    /** Distingue relógio da VELA de tempo de EXPIRAÇÃO. Retorna (segundosVela, segundosExpiracao). */
    fun classifyTimers(entries: List<TimerText>, chartTopPx: Int, chartBottomPx: Int): Pair<Int?, Int?> {
        var candle: Int? = null; var expiry: Int? = null
        for (e in entries) {
            val sec = e.seconds
            val byKeyword = e.context.contains("expir", ignoreCase = true)
            val inChart = e.yCenter in chartTopPx..chartBottomPx
            if (byKeyword || !inChart) { if (expiry == null) expiry = sec } else { if (candle == null) candle = sec }
        }
        return candle to expiry
    }
}

data class TimerText(val seconds: Int, val yCenter: Int, val context: String)

/** Contrato para uma futura fonte autorizada de dados (API oficial, arquivo exportado, etc.). */
interface AvalonDataSource {
    val name: String
    suspend fun candles(asset: String, timeframeMinutes: Int, count: Int): List<Candle>
}

/** Comparação do modo híbrido: série visual (relativa) x série independente (absoluta). */
object HybridChecker {
    fun compare(visual: List<Candle>, independent: List<Candle>, n: Int = 20): List<String> {
        val notes = mutableListOf<String>()
        if (visual.size < n || independent.size < n) return listOf("Híbrido: séries curtas demais para comparar")
        val v = visual.takeLast(n).map { it.c }; val i = independent.takeLast(n).map { it.c }
        val corr = pearson(v, i)
        val sv = v.last() - v.first(); val si = i.last() - i.first()
        notes += "Híbrido: correlação das últimas $n velas = ${"%.2f".format(corr)}"
        if (corr < 0.8) notes += "INCONSISTÊNCIA: série visual e série independente divergem (correlação < 0,80). Verifique ativo/tempo gráfico/defasagem."
        if (sv * si < 0) notes += "INCONSISTÊNCIA: direção das últimas $n velas é oposta entre as duas fontes."
        return notes
    }

    fun pearson(a: List<Double>, b: List<Double>): Double {
        val ma = a.average(); val mb = b.average()
        var num = 0.0; var da = 0.0; var db = 0.0
        for (k in a.indices) { num += (a[k] - ma) * (b[k] - mb); da += (a[k] - ma) * (a[k] - ma); db += (b[k] - mb) * (b[k] - mb) }
        return if (da == 0.0 || db == 0.0) 0.0 else num / Math.sqrt(da * db)
    }
}
