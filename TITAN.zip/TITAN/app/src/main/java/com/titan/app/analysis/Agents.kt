package com.titan.app.analysis

import com.titan.app.core.*
import com.titan.app.indicators.*
import com.titan.app.patterns.CandlePatterns
import com.titan.app.patterns.ChartPatterns
import com.titan.app.strategies.MarketStructure
import kotlin.math.abs

data class AnalysisConfig(
    val payout: Double = 0.80,       // retorno líquido por operação vencedora (config. do usuário)
    val horizonCandles: Int = 1,     // horizonte da hipótese em velas
    val minSample: Int = 30          // amostra mínima para falar em confiança estatística
)

private fun Bias.sign() = when (this) { Bias.ALTA -> 1.0; Bias.BAIXA -> -1.0; else -> 0.0 }
private fun clamp(x: Double) = x.coerceIn(-1.0, 1.0)
private fun fmt(x: Double) = "%.2f".format(x)

/** TITAN Vision: avalia a QUALIDADE da leitura visual (não gera viés direcional). */
object TitanVision {
    fun report(read: VisualRead?, origin: DataOrigin): ModuleReport {
        if (read == null || origin != DataOrigin.VISUAL) {
            return ModuleReport("TITAN Vision", 0.0, 1.0,
                "Sem leitura visual nesta análise (origem dos dados: $origin).")
        }
        var q = 1.0
        val w = mutableListOf<String>()
        val ev = mutableListOf<Evidence>()
        if (read.platform == null) { q -= 0.15; w += "Plataforma não identificada no print" }
        if (read.asset == null) { q -= 0.25; w += "Ativo não identificado" }
        if (read.timeframe == null) { q -= 0.25; w += "Tempo gráfico não identificado" }
        if (read.candles.size < 30) { q -= 0.3; w += "Poucas velas extraídas (${read.candles.size})" }
        if (read.expirySeconds == null) w += "Tempo de expiração não lido (não confundir com tempo restante da vela)"
        ev += Evidence("Velas extraídas", 0.0, "${read.candles.size} velas (preço relativo em pixels)")
        read.candleSecondsLeft?.let { ev += Evidence("Tempo restante da vela", 0.0, "${it}s") }
        return ModuleReport("TITAN Vision", 0.0, q.coerceIn(0.0, 1.0),
            "Qualidade da leitura visual: ${(q * 100).toInt()}%", ev, w + read.notes)
    }
}

/** TITAN Technical Analyst: indicadores agrupados por FAMÍLIA (evita contar indicadores redundantes). */
object TechnicalAnalyst {
    fun report(cs: List<Candle>): ModuleReport {
        if (cs.size < 30) return ModuleReport("TITAN Technical Analyst", 0.0, 0.0,
            "Velas insuficientes (${cs.size}); mínimo 30.", warnings = listOf("Dados insuficientes"))
        val c = cs.closes(); val h = cs.highs(); val l = cs.lows(); val v = cs.vols()
        val ev = mutableListOf<Evidence>()
        val trend = mutableListOf<Double>(); val mom = mutableListOf<Double>()
        val vol = mutableListOf<Double>(); val volu = mutableListOf<Double>()

        val last = c.last()
        val e9 = Indicators.ema(c, 9).lastValid(); val e21 = Indicators.ema(c, 21).lastValid()
        val e50 = Indicators.ema(c, 50).lastValid(); val s20 = Indicators.sma(c, 20).lastValid()
        if (!e21.isNaN() && !e9.isNaN()) {
            val s = if (e9 > e21) 0.6 else -0.6
            trend += s; ev += Evidence("EMA 9/21", s, "EMA9 ${fmt(e9)} ${if (e9 > e21) ">" else "<"} EMA21 ${fmt(e21)}")
        }
        if (!e50.isNaN()) { val s = if (last > e50) 0.5 else -0.5; trend += s; ev += Evidence("EMA 50", s, "preço ${if (last > e50) "acima" else "abaixo"} da EMA50") }
        if (!s20.isNaN()) { val s = if (last > s20) 0.3 else -0.3; trend += s; ev += Evidence("SMA 20", s, "preço ${if (last > s20) "acima" else "abaixo"} da SMA20") }

        val ich = Indicators.ichimoku(h, l)
        val tk = ich.tenkan.lastValid(); val kj = ich.kijun.lastValid(); val sa = ich.spanA.lastValid(); val sb = ich.spanB.lastValid()
        if (!tk.isNaN() && !kj.isNaN()) {
            var s = if (tk > kj) 0.4 else -0.4
            if (!sa.isNaN() && !sb.isNaN()) s += if (last > maxOf(sa, sb)) 0.4 else if (last < minOf(sa, sb)) -0.4 else 0.0
            trend += clamp(s); ev += Evidence("Ichimoku", clamp(s), "Tenkan ${if (tk > kj) ">" else "<"} Kijun; posição vs nuvem")
        }
        val sar = Indicators.parabolicSar(h, l).lastValid()
        if (!sar.isNaN()) { val s = if (last > sar) 0.4 else -0.4; trend += s; ev += Evidence("Parabolic SAR", s, "SAR ${if (last > sar) "abaixo" else "acima"} do preço") }

        val adx = Indicators.adx(h, l, c).lastValid()
        if (!adx.isNaN()) ev += Evidence("ADX", 0.0, "ADX ${fmt(adx)} (${if (adx > 25) "tendência definida" else "mercado sem tendência forte"})")

        val rsi = Indicators.rsi(c).lastValid()
        if (!rsi.isNaN()) {
            val s = when { rsi < 30 -> 0.6; rsi > 70 -> -0.6; rsi in 50.0..65.0 -> 0.2; rsi in 35.0..50.0 -> -0.2; else -> 0.0 }
            mom += s; ev += Evidence("RSI(14)", s, "RSI ${fmt(rsi)}")
        }
        val m = Indicators.macd(c)
        val mh = m.hist.lastValid()
        if (!mh.isNaN()) { val s = if (mh > 0) 0.4 else -0.4; mom += s; ev += Evidence("MACD", s, "histograma ${fmt(mh)}") }
        val (k, d) = Indicators.stochastic(h, l, c)
        val kv = k.lastValid(); val dv = d.lastValid()
        if (!kv.isNaN() && !dv.isNaN()) {
            val s = when { kv < 20 && kv > dv -> 0.5; kv > 80 && kv < dv -> -0.5; kv > dv -> 0.15; else -> -0.15 }
            mom += s; ev += Evidence("Estocástico", s, "%K ${fmt(kv)} / %D ${fmt(dv)}")
        }
        val cci = Indicators.cci(h, l, c).lastValid()
        if (!cci.isNaN()) {
            val s = when { cci < -100 -> 0.4; cci > 100 -> -0.4; else -> 0.0 }
            mom += s; ev += Evidence("CCI", s, "CCI ${fmt(cci)}")
        }
        val bb = Indicators.bollinger(c)
        val up = bb.upper.lastValid(); val lo = bb.lower.lastValid()
        if (!up.isNaN()) {
            val s = when { last < lo -> 0.5; last > up -> -0.5; else -> 0.0 }
            vol += s; ev += Evidence("Bollinger", s, "preço ${if (last < lo) "abaixo da banda inferior" else if (last > up) "acima da banda superior" else "dentro das bandas"}")
        }
        val atr = Indicators.atr(h, l, c).lastValid()
        if (!atr.isNaN()) ev += Evidence("ATR(14)", 0.0, "ATR ${fmt(atr)}")
        if (v.any { it > 0 }) {
            val obv = Indicators.obv(c, v); val ob = Indicators.sma(obv, 10).lastValid()
            if (!ob.isNaN()) { val s = if (obv.last() > ob) 0.3 else -0.3; volu += s; ev += Evidence("OBV", s, "OBV ${if (obv.last() > ob) "acima" else "abaixo"} da média") }
            val vw = Indicators.vwap(h, l, c, v).lastValid()
            if (!vw.isNaN()) { val s = if (last > vw) 0.3 else -0.3; volu += s; ev += Evidence("VWAP", s, "preço ${if (last > vw) "acima" else "abaixo"} do VWAP") }
        } else {
            ev += Evidence("Volume/OBV/VWAP", 0.0, "indisponíveis: dados sem volume (não estimados)")
        }
        val pv = Indicators.pivots(cs[cs.size - 2].h, cs[cs.size - 2].l, cs[cs.size - 2].c)
        ev += Evidence("Pivot Points", 0.0, "P ${fmt(pv.p)}  R1 ${fmt(pv.r1)}  S1 ${fmt(pv.s1)}")
        val hi = cs.takeLast(50).maxOf { it.h }; val lw = cs.takeLast(50).minOf { it.l }
        val fib = Indicators.fibonacci(hi, lw, e21 > e50)
        ev += Evidence("Fibonacci", 0.0, "61,8% em ${fmt(fib["61.8%"] ?: Double.NaN)}")

        val cp = CandlePatterns.detect(cs, onlyLast = 3)
        val patScores = cp.map { Evidence("Vela: ${it.name}", it.bias.sign() * 0.4, "índice ${it.index}") }
        ev += patScores
        val gp = ChartPatterns.detect(cs)
        ev += gp.map { Evidence("Gráfico: ${it.name}", it.bias.sign() * 0.4 * it.confidence * 2, it.note) }

        fun avg(x: List<Double>) = if (x.isEmpty()) null else x.average()
        val fam = listOfNotNull(
            avg(trend)?.let { it to 0.35 }, avg(mom)?.let { it to 0.25 }, avg(vol)?.let { it to 0.10 },
            avg(volu)?.let { it to 0.10 },
            avg(patScores.map { it.score } + gp.map { it.bias.sign() * 0.4 * it.confidence * 2 })?.let { it to 0.20 }
        )
        val wsum = fam.sumOf { it.second }
        var score = if (wsum == 0.0) 0.0 else fam.sumOf { it.first * it.second } / wsum
        // Sem tendência definida, o componente de tendência perde força
        if (!adx.isNaN() && adx < 20) score *= 0.7
        score = clamp(score)
        val summary = "Viés técnico ${if (score > 0.15) "de alta" else if (score < -0.15) "de baixa" else "neutro"} (score ${fmt(score)}), " +
            "${cp.size} padrão(ões) de vela e ${gp.size} padrão(ões) gráfico(s) recentes."
        return ModuleReport("TITAN Technical Analyst", score, 1.0, summary, ev)
    }
}

data class QuantStats(val n: Int, val upRate: Double, val low: Double, val high: Double, val state: String)

/** TITAN Quant Analyst: frequência histórica condicional (mesmo "estado" no passado -> próxima direção). */
object QuantAnalyst {
    private fun states(cs: List<Candle>): IntArray {
        val c = cs.closes(); val e21 = Indicators.ema(c, 21); val e50 = Indicators.ema(c, 50); val r = Indicators.rsi(c)
        return IntArray(cs.size) { i ->
            if (e21[i].isNaN() || e50[i].isNaN() || r[i].isNaN()) -1
            else (if (e21[i] > e50[i]) 1 else 0) * 3 + (if (r[i] < 35) 0 else if (r[i] > 65) 2 else 1)
        }
    }
    private fun name(s: Int) = (if (s / 3 == 1) "EMA21>EMA50" else "EMA21<EMA50") + ", RSI " + listOf("baixo", "médio", "alto")[s % 3]

    fun stats(cs: List<Candle>, cfg: AnalysisConfig): QuantStats? {
        if (cs.size < 80) return null
        val st = states(cs)
        val cur = st.last()
        if (cur < 0) return null
        var n = 0; var up = 0
        for (i in 0 until cs.size - 1 - cfg.horizonCandles) {   // exclui o presente: sem vazamento
            if (st[i] == cur) {
                n++
                if (cs[i + cfg.horizonCandles].c > cs[i].c) up++
            }
        }
        val (lo, hi) = Stats.wilson(up, n)
        return QuantStats(n, if (n == 0) 0.0 else up.toDouble() / n, lo, hi, name(cur))
    }

    fun report(cs: List<Candle>, cfg: AnalysisConfig): ModuleReport {
        val s = stats(cs, cfg) ?: return ModuleReport("TITAN Quant Analyst", 0.0, 0.0,
            "Histórico insuficiente (mínimo 80 velas) para estatística condicional.",
            warnings = listOf("Sem confiança estatística disponível"))
        val be = Stats.breakEven(cfg.payout)
        val ev = mutableListOf(Evidence("Amostra", 0.0, "n=${s.n} ocorrências do estado [${s.state}]"),
            Evidence("Taxa histórica de alta", 0.0, "${(s.upRate * 100).toInt()}% (IC95%: ${(s.low * 100).toInt()}–${(s.high * 100).toInt()}%)"),
            Evidence("Ponto de equilíbrio", 0.0, "${(be * 100).toInt()}% para payout ${(cfg.payout * 100).toInt()}%"))
        if (s.n < cfg.minSample) {
            return ModuleReport("TITAN Quant Analyst", 0.0, 0.2,
                "Amostra pequena (n=${s.n} < ${cfg.minSample}): sem conclusão estatística.", ev,
                listOf("Amostra insuficiente"))
        }
        // Só há "vantagem" se o intervalo inteiro ficar de um lado do ponto de equilíbrio
        val score = when {
            s.low > be -> clamp((s.upRate - 0.5) * 4)
            1 - s.high > be -> clamp((s.upRate - 0.5) * 4)
            else -> 0.0
        }
        val msg = if (score == 0.0) "Sem vantagem estatística distinguível do acaso/custos nesta amostra."
        else "Vantagem histórica ${if (score > 0) "de alta" else "de baixa"} acima do ponto de equilíbrio (não garante o futuro)."
        return ModuleReport("TITAN Quant Analyst", score, 1.0, msg, ev)
    }
}

/** TITAN Market Analyst: estrutura, volatilidade e multi-tempo. */
object MarketAnalyst {
    fun report(cs: List<Candle>, baseMinutes: Int?): Pair<ModuleReport, MtfResult> {
        val mtf = MultiTimeframe.analyze(cs, baseMinutes)
        if (cs.size < 30) return ModuleReport("TITAN Market Analyst", 0.0, 0.0, "Velas insuficientes.",
            warnings = listOf("Dados insuficientes")) to mtf
        val st = MarketStructure.analyze(cs)
        val h = cs.highs(); val l = cs.lows(); val c = cs.closes()
        val atrArr = Indicators.atr(h, l, c)
        val atr = atrArr.lastValid()
        val hist = atrArr.filter { !it.isNaN() }
        val pct = if (hist.size < 20 || atr.isNaN()) null else hist.count { it <= atr }.toDouble() / hist.size
        val ev = mutableListOf<Evidence>()
        val sTrend = st.trend.sign() * 0.7
        ev += Evidence("Estrutura (Dow)", sTrend, st.description)
        st.bos?.let { ev += Evidence("BOS", if (it.contains("alta")) 0.4 else -0.4, it) }
        st.liquiditySweep?.let { ev += Evidence("Sweep de liquidez", if (it.contains("abaixo do fundo")) 0.4 else -0.4, it) }
        if (st.fairValueGaps > 0) ev += Evidence("FVG abertos", 0.0, "${st.fairValueGaps} gap(s) de valor justo em aberto (conceito ICT)")
        pct?.let { ev += Evidence("Volatilidade", 0.0, "ATR no percentil ${(it * 100).toInt()} do período") }
        ev += Evidence("Multi-tempo", mtf.confluence * 0.6, mtf.note)
        mtf.trends.forEach { ev += Evidence("TF ${it.label}", it.bias.sign() * 0.3, it.note) }
        val warns = mtf.disagreements.toMutableList()
        if (pct != null && pct > 0.95) warns += "Volatilidade extrema (ATR acima do percentil 95)"
        if (pct != null && pct < 0.05) warns += "Volatilidade muito baixa (movimentos pequenos frente ao ruído)"
        val score = clamp(sTrend * 0.6 + mtf.confluence * 0.4)
        return ModuleReport("TITAN Market Analyst", score, 1.0,
            "${st.description}. ${mtf.note}.", ev, warns) to mtf
    }
}

/** TITAN Auditor: procura erros, contradições e informação insuficiente. quality<0.5 BLOQUEIA sinais. */
object TitanAuditor {
    fun report(cs: List<Candle>, reports: List<ModuleReport>, read: VisualRead?, origin: DataOrigin,
               baseMinutes: Int?, staleSeconds: Long?): ModuleReport {
        var q = 1.0
        val w = mutableListOf<String>()
        if (cs.size < 50) { q -= 0.5; w += "Menos de 50 velas: análise pouco confiável" }
        if (baseMinutes == null) { q -= 0.2; w += "Tempo gráfico desconhecido" }
        if (origin == DataOrigin.SINTETICO_DEMO) { q -= 0.6; w += "Dados SINTÉTICOS de demonstração: nunca usar para decisão" }
        if (origin == DataOrigin.VISUAL) w += "Preços vindos de print são RELATIVOS (pixels); indicadores servem para formato/tendência, não para nível absoluto"
        if (staleSeconds != null && staleSeconds > 30) { q -= 0.2; w += "Leitura com ${staleSeconds}s de atraso: sinal pode estar defasado" }
        val vis = reports.firstOrNull { it.module == "TITAN Vision" }
        if (vis != null && vis.quality < 0.6) { q -= 0.2; w += "Leitura visual com baixa qualidade" }
        val tech = reports.firstOrNull { it.module == "TITAN Technical Analyst" }
        val mkt = reports.firstOrNull { it.module == "TITAN Market Analyst" }
        if (tech != null && mkt != null && tech.score * mkt.score < 0 && abs(tech.score) > 0.2 && abs(mkt.score) > 0.2) {
            q -= 0.25; w += "CONTRADIÇÃO: viés técnico e contexto de mercado apontam direções opostas"
        }
        reports.filter { it.quality < 0.3 && it.module != "TITAN Vision" }.forEach { w += "${it.module}: dados insuficientes" }
        if (read != null && read.expirySeconds != null && read.candleSecondsLeft != null) {
            w += "Lembrete: tempo restante da vela (${read.candleSecondsLeft}s) ≠ expiração configurada (${read.expirySeconds}s)"
        }
        q = q.coerceIn(0.0, 1.0)
        return ModuleReport("TITAN Auditor", 0.0, q,
            if (q >= 0.5) "Auditoria: sem impeditivos (qualidade ${(q * 100).toInt()}%)" else "Auditoria: ANÁLISE BLOQUEADA (qualidade ${(q * 100).toInt()}%)",
            warnings = w)
    }
}

/** TITAN Decision Engine: reúne evidências e produz conclusão EXPLICÁVEL (nunca certeza). */
object DecisionEngine {
    fun decide(asset: String, timeframe: String, cs: List<Candle>, origin: DataOrigin, read: VisualRead?,
               cfg: AnalysisConfig, now: Long = System.currentTimeMillis()): Decision {
        val base = Timeframes.minutes(timeframe)
        val vision = TitanVision.report(read, origin)
        val tech = TechnicalAnalyst.report(cs)
        val quant = QuantAnalyst.report(cs, cfg)
        val (mkt, mtf) = MarketAnalyst.report(cs, base)
        val stale = read?.let { (now - it.readAt) / 1000 }
        val audit = TitanAuditor.report(cs, listOf(vision, tech, quant, mkt), read, origin, base, stale)
        val reports = listOf(vision, tech, quant, mkt, audit)

        val parts = listOf(tech to 0.35, mkt to 0.30, quant to 0.35).filter { it.first.quality >= 0.5 }
        val wsum = parts.sumOf { it.second }
        val score = if (wsum == 0.0) 0.0 else clamp(parts.sumOf { it.first.score * it.second } / wsum)
        val bias = when { score > 0.25 -> Bias.ALTA; score < -0.25 -> Bias.BAIXA; else -> Bias.NEUTRO }
        val dir = bias.sign()
        val qs = QuantAnalyst.stats(cs, cfg)

        val met = mutableListOf<String>(); val miss = mutableListOf<String>()
        fun crit(ok: Boolean, text: String) { if (ok) met += text else miss += text }
        crit(mkt.quality >= 0.5 && dir != 0.0 && mkt.score * dir > 0.2, "Estrutura/contexto de mercado alinhados ao viés")
        crit(dir != 0.0 && mtf.confluence * dir > 0.3 && mtf.disagreements.isEmpty(), "Confluência entre tempos gráficos")
        crit(dir != 0.0 && tech.score * dir > 0.2, "Momentum e indicadores técnicos a favor")
        crit(dir != 0.0 && quant.score * dir > 0.0 && quant.quality >= 1.0, "Vantagem estatística acima do ponto de equilíbrio")
        crit(mkt.warnings.none { it.startsWith("Volatilidade") }, "Volatilidade em faixa operável")
        crit(audit.quality >= 0.8, "Dados e leitura com qualidade suficiente")
        crit(audit.warnings.none { it.startsWith("CONTRADIÇÃO") }, "Sem contradição entre módulos")

        val blocked = audit.quality < 0.5
        val kind = when {
            blocked || bias == Bias.NEUTRO -> SignalKind.AUSENCIA_DE_SINAL
            miss.isEmpty() -> SignalKind.CONFIRMACAO
            met.size >= 5 -> SignalKind.OPORTUNIDADE
            else -> SignalKind.AUSENCIA_DE_SINAL
        }
        val finalBias = if (kind == SignalKind.AUSENCIA_DE_SINAL) Bias.NEUTRO else bias
        val conf = if (qs != null && qs.n >= cfg.minSample && finalBias != Bias.NEUTRO)
            (if (finalBias == Bias.ALTA) qs.low else 1 - qs.high) else null

        val expl = buildString {
            append("Conclusão: ${kind.name.replace('_', ' ')}")
            if (finalBias != Bias.NEUTRO) append(" com viés de ${finalBias.name.lowercase()}")
            append(". Critérios atendidos: ${met.size}/${met.size + miss.size}. ")
            if (blocked) append("Bloqueado pelo Auditor. ")
            if (miss.isNotEmpty()) append("Faltam: ${miss.joinToString("; ")}. ")
            append(if (conf != null) "Confiança estatística (limite inferior 95%): ${(conf * 100).toInt()}% — com amostra n=${qs!!.n}; " else "Confiança estatística indisponível (amostra insuficiente); ")
            append("isto é uma hipótese baseada em dados passados, não uma previsão nem garantia.")
        }
        return Decision(asset, timeframe, finalBias, kind, score, conf, qs?.n ?: 0, reports, met, miss, expl, now)
    }
}
