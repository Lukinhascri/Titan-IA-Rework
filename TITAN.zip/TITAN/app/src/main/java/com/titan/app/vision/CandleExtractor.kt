package com.titan.app.vision

import android.graphics.Bitmap
import com.titan.app.core.Candle

/**
 * Extrai velas de um print por análise de cor (verde/vermelho configuráveis).
 * Limitações: preço RELATIVO (escala em pixels, invertida); velas coladas podem se fundir;
 * precisa de calibração das cores/região com prints reais da plataforma.
 */
object CandleExtractor {
    private fun near(p: Int, ref: Int, tol2: Int): Boolean {
        val dr = ((p shr 16) and 0xFF) - ((ref shr 16) and 0xFF)
        val dg = ((p shr 8) and 0xFF) - ((ref shr 8) and 0xFF)
        val db = (p and 0xFF) - (ref and 0xFF)
        return dr * dr + dg * dg + db * db <= tol2
    }

    fun extract(bmp: Bitmap, up: Int, down: Int, tol: Int, topFrac: Float, botFrac: Float): Pair<List<Candle>, List<String>> {
        val notes = mutableListOf<String>()
        val w = bmp.width; val h = bmp.height
        val y0 = (h * topFrac).toInt().coerceIn(0, h - 2)
        val y1 = (h * botFrac).toInt().coerceIn(y0 + 1, h)
        val hh = y1 - y0
        val px = IntArray(w * hh)
        bmp.getPixels(px, 0, w, 0, y0, w, hh)
        val tol2 = tol * tol
        val cntU = IntArray(w); val topU = IntArray(w) { Int.MAX_VALUE }; val botU = IntArray(w) { -1 }
        val cntD = IntArray(w); val topD = IntArray(w) { Int.MAX_VALUE }; val botD = IntArray(w) { -1 }
        for (y in 0 until hh) {
            val row = y * w
            for (x in 0 until w) {
                val p = px[row + x]
                if (near(p, up, tol2)) { cntU[x]++; if (y < topU[x]) topU[x] = y; botU[x] = y }
                else if (near(p, down, tol2)) { cntD[x]++; if (y < topD[x]) topD[x] = y; botD[x] = y }
            }
        }
        val type = IntArray(w) { x ->
            when {
                cntU[x] >= 3 && cntU[x] >= cntD[x] -> 1
                cntD[x] >= 3 -> -1
                else -> 0
            }
        }
        val out = mutableListOf<Candle>()
        var x = 0; var idx = 0L
        while (x < w) {
            if (type[x] == 0) { x++; continue }
            val t = type[x]; var e = x
            while (e + 1 < w && type[e + 1] == t) e++
            val width = e - x + 1
            val tops = if (t == 1) topU else topD; val bots = if (t == 1) botU else botD; val cnts = if (t == 1) cntU else cntD
            var gTop = Int.MAX_VALUE; var gBot = -1
            for (c in x..e) { gTop = minOf(gTop, tops[c]); gBot = maxOf(gBot, bots[c]) }
            if (gBot - gTop >= 2) {
                // corpo: linhas onde a maioria das colunas do grupo está colorida
                var bTop = gBot; var bBot = gTop
                val need = maxOf(1, (width * 0.6).toInt())
                if (width >= 3) {
                    val ref = if (t == 1) up else down
                    for (y in gTop..gBot) {
                        var k = 0
                        for (c in x..e) if (near(px[y * w + c], ref, tol2)) k++
                        if (k >= need) { bTop = minOf(bTop, y); bBot = maxOf(bBot, y) }
                    }
                }
                if (bBot < bTop) { bTop = gTop; bBot = gBot }      // vela fina: corpo = extensão total (sem como separar)
                fun price(y: Int) = (hh - y).toDouble()
                val high = price(gTop); val low = price(gBot)
                val bodyHi = price(bTop); val bodyLo = price(bBot)
                val o = if (t == 1) bodyLo else bodyHi
                val c = if (t == 1) bodyHi else bodyLo
                out += Candle(idx++, o, high, low, c, 0.0)
            }
            x = e + 1
        }
        if (out.size < 10) notes += "Poucas velas detectadas (${out.size}): calibre as cores e a região do gráfico em Configurações."
        notes += "Preço extraído é RELATIVO (pixels); sem leitura do eixo de preço."
        return out to notes
    }
}
