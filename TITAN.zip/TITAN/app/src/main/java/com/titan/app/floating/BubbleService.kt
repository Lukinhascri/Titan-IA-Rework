package com.titan.app.floating

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import androidx.core.app.NotificationCompat
import com.titan.app.core.BubbleStatus
import com.titan.app.core.TitanState
import com.titan.app.ui.MainActivity
import kotlin.math.abs
import kotlin.math.sin

/** Bolinha flutuante sobre outros apps (permissão "Sobrepor a outros apps" concedida pelo usuário). */
class BubbleService : Service() {
    companion object {
        const val ACTION_SHOW = "titan.bubble.show"
        const val ACTION_HIDE = "titan.bubble.hide"
        const val ACTION_STOP = "titan.bubble.stop"
        @Volatile var instance: BubbleService? = null
        private const val CH = "titan_bubble"
    }

    private lateinit var wm: WindowManager
    private var view: BubbleView? = null
    private lateinit var lp: WindowManager.LayoutParams
    private val main = Handler(Looper.getMainLooper())
    private var userHidden = false
    private var captureHidden = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { removeView(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY }
            ACTION_HIDE -> { userHidden = true; applyVisibility() }
            ACTION_SHOW -> { userHidden = false; applyVisibility() }
        }
        startFg()
        if (view == null) addView()
        applyVisibility()
        return START_STICKY
    }

    private fun addView() {
        val v = BubbleView(this)
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        lp = WindowManager.LayoutParams(v.sizePx, v.sizePx, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 300 }
        v.onMove = { dx, dy -> lp.x += dx; lp.y += dy; try { wm.updateViewLayout(v, lp) } catch (_: Exception) {} }
        v.onTap = {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        }
        v.onLong = { v.minimized = !v.minimized; lp.width = v.sizePx; lp.height = v.sizePx; try { wm.updateViewLayout(v, lp) } catch (_: Exception) {} }
        try { wm.addView(v, lp); view = v } catch (e: Exception) { TitanState.error = "Sem permissão para sobrepor apps: ${e.message}" }
    }

    private fun removeView() { view?.stop(); try { view?.let { wm.removeView(it) } } catch (_: Exception) {}; view = null }

    private fun applyVisibility() { view?.visibility = if (userHidden || captureHidden) View.INVISIBLE else View.VISIBLE }

    /** Esconde a bolinha por instantes durante a captura, para ela não aparecer no print analisado. */
    fun setCaptureHidden(h: Boolean) { captureHidden = h; main.post { applyVisibility() } }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CH, "Bolinha TITAN", NotificationManager.IMPORTANCE_LOW))
        fun pi(a: String, code: Int) = PendingIntent.getService(this, code, Intent(this, BubbleService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE)
        val n: Notification = NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("TITAN ativo")
            .setContentText("Bolinha flutuante em execução")
            .addAction(0, "Ocultar", pi(ACTION_HIDE, 10)).addAction(0, "Mostrar", pi(ACTION_SHOW, 11)).addAction(0, "Fechar", pi(ACTION_STOP, 12))
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(3, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(3, n)
    }

    override fun onDestroy() { removeView(); instance = null; super.onDestroy() }
}

/** Desenho da bolinha: anel colorido por status, pulso animado e ponto de conexão. */
class BubbleView(ctx: Context) : View(ctx) {
    var minimized = false
    val sizePx get() = (if (minimized) 34 else 64).dp
    var onMove: (Int, Int) -> Unit = { _, _ -> }
    var onTap: () -> Unit = {}
    var onLong: () -> Unit = {}

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1600; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }
    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()
    private var lx = 0f; private var ly = 0f; private var moved = false; private var longFired = false
    private val longPress = Runnable { if (!moved) { longFired = true; onLong() } }

    init { anim.start() }
    fun stop() { anim.cancel() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val cx = w / 2; val r = w / 2 - 6.dp
        val st = TitanState.bubbleStatus()
        val ring = when (st) {
            BubbleStatus.OFFLINE -> 0xFF64748B.toInt(); BubbleStatus.CONECTADO -> 0xFF22D3EE.toInt()
            BubbleStatus.ANALISANDO -> 0xFF2D7BFF.toInt(); BubbleStatus.ALERTA -> 0xFFF59E0B.toInt(); BubbleStatus.ERRO -> 0xFFEF4444.toInt()
        }
        val pulse = (sin(phase * 2 * Math.PI).toFloat() + 1) / 2
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cx, r * 1.4f, intArrayOf(ring and 0x00FFFFFF or (((90 * pulse).toInt() + 30) shl 24), 0x00000000), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cx, w / 2, p)
        p.shader = LinearGradient(0f, 0f, w, w, 0xFF2D7BFF.toInt(), 0xFF8B5CF6.toInt(), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cx, r, p)
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = 3.dp.toFloat(); p.color = ring
        if (st == BubbleStatus.ANALISANDO) c.drawArc(cx - r, cx - r, cx + r, cx + r, phase * 360, 100f, false, p)
        else c.drawCircle(cx, cx, r, p)
        if (!minimized) {
            p.style = Paint.Style.FILL; p.color = Color.WHITE; p.textSize = 20.dp.toFloat(); p.typeface = Typeface.DEFAULT_BOLD; p.textAlign = Paint.Align.CENTER
            c.drawText("T", cx, cx + 7.dp, p)
        }
        // ponto de conexão (verde = rede ok, vermelho = sem rede)
        p.color = if (TitanState.connected) 0xFF22C55E.toInt() else 0xFFEF4444.toInt()
        c.drawCircle(w - 9.dp, 9.dp.toFloat(), 5.dp.toFloat(), p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { lx = e.rawX; ly = e.rawY; moved = false; longFired = false; postDelayed(longPress, 600) }
            MotionEvent.ACTION_MOVE -> {
                val dx = (e.rawX - lx).toInt(); val dy = (e.rawY - ly).toInt()
                if (abs(dx) + abs(dy) > 6) { moved = true; removeCallbacks(longPress); onMove(dx, dy); lx = e.rawX; ly = e.rawY }
            }
            MotionEvent.ACTION_UP -> { removeCallbacks(longPress); if (!moved && !longFired) onTap() }
            MotionEvent.ACTION_CANCEL -> removeCallbacks(longPress)
        }
        return true
    }
}
