package com.titan.app.patterns

import com.titan.app.core.Bias
import com.titan.app.core.Candle
import kotlin.math.abs

data class Swing(val index: Int, val price: Double, val isHigh: Boolean)

data class ChartHit(val name: String, val bias: Bias, val confidence: Double, val note: String)

/**
 * Padrões gráficos por HEURÍSTICA sobre swings (fractais). São aproximações:
 * a "confidence" é a qualidade geométrica do encaixe (0..1), NÃO uma probabilidade de acerto.
 */
object ChartPatterns {
    fun swings(cs: List<Candle>, w: Int = 3): List<Swing> {
        val out = mutableListOf<Swing>()
        for (i in w until cs.size - w) {
            var hi = true; var lo = true
            for (j in 1..w) {
                if (cs[i].h <= cs[i - j].h || cs[i].h <= cs[i + j].h) hi = false
                if (cs[i].l >= cs[i - j].l || cs[i].l >= cs[i + j].l) lo = false
            }
            if (hi) out += Swing(i, cs[i].h, true)
            if (lo) out += Swing(i, cs[i].l, false)
        }
        return out
    }

    /** Inclinação (por vela) de regressão linear. */
    fun slope(pts: List<Swing>): Double {
        if (pts.size < 2) return 0.0
        val n = pts.size
        val mx = pts.map { it.index.toDouble() }.average()
        val my = pts.map { it.price }.average()
        var num = 0.0; var den = 0.0
        for (p in pts) { num += (p.index - mx) * (p.price - my); den += (p.index - mx) * (p.index - mx) }
        return if (den == 0.0) 0.0 else num / den
    }

    fun detect(cs: List<Candle>): List<ChartHit> {
        if (cs.size < 30) return emptyList()
        val sw = swings(cs)
        val highs = sw.filter { it.isHigh }
        val lows = sw.filter { !it.isHigh }
        val out = mutableListOf<ChartHit>()
        val avgR = cs.map { it.range }.average()
        val tol = avgR * 1.2
        val last = cs.last()

        // Topo duplo / fundo duplo
        if (highs.size >= 2) {
            val a = highs[highs.size - 2]; val b = highs.last()
            val valley = lows.lastOrNull { it.index in a.index..b.index }
            if (abs(a.price - b.price) <= tol && b.index - a.index >= 5 && valley != null && a.price - valley.price > 2 * avgR)
                out += ChartHit("Topo duplo", Bias.BAIXA, 1 - abs(a.price - b.price) / tol / 2, "dois topos próximos com vale entre eles")
        }
        if (lows.size >= 2) {
            val a = lows[lows.size - 2]; val b = lows.last()
            val peak = highs.lastOrNull { it.index in a.index..b.index }
            if (abs(a.price - b.price) <= tol && b.index - a.index >= 5 && peak != null && peak.price - a.price > 2 * avgR)
                out += ChartHit("Fundo duplo", Bias.ALTA, 1 - abs(a.price - b.price) / tol / 2, "dois fundos próximos com pico entre eles")
        }
        // Ombro-cabeça-ombro (3 topos: cabeça maior que ombros, ombros similares)
        if (highs.size >= 3) {
            val (l, h, r) = highs.takeLast(3)
            if (h.price > l.price + avgR && h.price > r.price + avgR && abs(l.price - r.price) <= tol * 1.5)
                out += ChartHit("Ombro-cabeça-ombro", Bias.BAIXA, 0.55, "cabeça acima de dois ombros semelhantes")
        }
        if (lows.size >= 3) {
            val (l, h, r) = lows.takeLast(3)
            if (h.price < l.price - avgR && h.price < r.price - avgR && abs(l.price - r.price) <= tol * 1.5)
                out += ChartHit("Ombro-cabeça-ombro invertido", Bias.ALTA, 0.55, "cabeça abaixo de dois ombros semelhantes")
        }
        // Linhas de tendência com os últimos 3-4 topos/fundos
        if (highs.size >= 3 && lows.size >= 3) {
            val hs = slope(highs.takeLast(4)); val ls = slope(lows.takeLast(4))
            val flat = avgR * 0.05
            val firstIdx = minOf(highs.takeLast(4).first().index, lows.takeLast(4).first().index)
            val widthStart = highs.takeLast(4).first().price - lows.takeLast(4).first().price
            val widthEnd = highs.last().price - lows.last().price
            val converging = widthEnd < widthStart * 0.85
            val sameSign = hs * ls > 0
            when {
                converging && abs(hs) < flat && ls > flat -> out += ChartHit("Triângulo ascendente", Bias.ALTA, 0.5, "topos planos, fundos subindo")
                converging && abs(ls) < flat && hs < -flat -> out += ChartHit("Triângulo descendente", Bias.BAIXA, 0.5, "fundos planos, topos caindo")
                converging && hs < -flat && ls > flat ->
                    out += ChartHit(if (cs.size - firstIdx <= 25) "Flâmula" else "Triângulo simétrico", Bias.NEUTRO, 0.5, "máximas caindo e mínimas subindo")
                converging && sameSign && hs > 0 -> out += ChartHit("Cunha ascendente", Bias.BAIXA, 0.45, "ambas as linhas sobem e convergem")
                converging && sameSign && hs < 0 -> out += ChartHit("Cunha descendente", Bias.ALTA, 0.45, "ambas as linhas descem e convergem")
                !converging && sameSign && abs(hs - ls) < avgR * 0.05 && hs > flat -> out += ChartHit("Canal de alta", Bias.ALTA, 0.5, "linhas paralelas ascendentes")
                !converging && sameSign && abs(hs - ls) < avgR * 0.05 && hs < -flat -> out += ChartHit("Canal de baixa", Bias.BAIXA, 0.5, "linhas paralelas descendentes")
                abs(hs) < flat && abs(ls) < flat -> out += ChartHit("Retângulo", Bias.NEUTRO, 0.5, "faixa lateral entre suporte e resistência")
            }
        }
        // Bandeira: impulso forte nas últimas ~20 velas seguido de correção curta e estreita
        if (cs.size >= 25) {
            val imp = cs[cs.size - 12].c - cs[cs.size - 25].c
            val corr = cs.last().c - cs[cs.size - 12].c
            val rng = cs.takeLast(12).let { s -> s.maxOf { it.h } - s.minOf { it.l } }
            if (abs(imp) > 6 * avgR && abs(corr) < abs(imp) * 0.4 && rng < abs(imp) * 0.6 && imp * corr < 0)
                out += ChartHit("Bandeira", if (imp > 0) Bias.ALTA else Bias.BAIXA, 0.45, "impulso seguido de correção estreita contra a tendência")
        }
        // Rompimento / falso rompimento do último swing relevante
        val prevHigh = highs.lastOrNull { it.index < cs.size - 3 }
        val prevLow = lows.lastOrNull { it.index < cs.size - 3 }
        if (prevHigh != null) {
            if (last.c > prevHigh.price && cs[cs.size - 2].c <= prevHigh.price)
                out += ChartHit("Rompimento de resistência", Bias.ALTA, 0.5, "fechou acima do último topo")
            val spike = cs.takeLast(3).any { it.h > prevHigh.price } && last.c < prevHigh.price
            if (spike) out += ChartHit("Falso rompimento de alta", Bias.BAIXA, 0.5, "passou do topo mas voltou a fechar abaixo")
        }
        if (prevLow != null) {
            if (last.c < prevLow.price && cs[cs.size - 2].c >= prevLow.price)
                out += ChartHit("Rompimento de suporte", Bias.BAIXA, 0.5, "fechou abaixo do último fundo")
            val spike = cs.takeLast(3).any { it.l < prevLow.price } && last.c > prevLow.price
            if (spike) out += ChartHit("Falso rompimento de baixa", Bias.ALTA, 0.5, "passou do fundo mas voltou a fechar acima")
        }
        return out
    }
}
