package com.titan.app.vision

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.titan.app.TitanApp
import com.titan.app.core.TitanState
import com.titan.app.floating.BubbleService
import kotlinx.coroutines.*

/**
 * Captura de tela AUTORIZADA pelo usuário (diálogo do sistema). Serviço em primeiro plano com
 * notificação visível; nada é escondido nem contorna permissões. Para parar: botão na notificação ou no app.
 */
class CaptureService : Service() {
    companion object {
        const val ACTION_START = "titan.capture.start"
        const val ACTION_STOP = "titan.capture.stop"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CH = "titan_capture"

        fun intentStart(ctx: Context, code: Int, data: Intent) =
            Intent(ctx, CaptureService::class.java).setAction(ACTION_START).putExtra(EXTRA_CODE, code).putExtra(EXTRA_DATA, data)
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var loop: Job? = null
    private var closed = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { shutdown(); return START_NOT_STICKY }
        if (intent?.action != ACTION_START) return START_NOT_STICKY
        closed = false
        startFg()
        val code = intent.getIntExtra(EXTRA_CODE, 0)
        @Suppress("DEPRECATION") val data: Intent? = intent.getParcelableExtra(EXTRA_DATA)
        if (data == null) { TitanState.error = "Permissão de captura inválida"; shutdown(); return START_NOT_STICKY }
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mpm.getMediaProjection(code, data)
            // Android 14+: callback é obrigatório antes de criar o VirtualDisplay
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { Handler(Looper.getMainLooper()).post { shutdown() } }
            }, Handler(Looper.getMainLooper()))
            val dm = resources.displayMetrics
            reader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)
            display = projection?.createVirtualDisplay("titan-capture", dm.widthPixels, dm.heightPixels, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
            TitanState.captureActive = true; TitanState.error = null
            TitanState.say("Captura de tela autorizada e iniciada")
            startLoop()
        } catch (e: Exception) {
            TitanState.error = "Falha ao iniciar captura: ${e.message}"; shutdown()
        }
        return START_NOT_STICKY
    }

    private fun startLoop() {
        loop?.cancel()
        loop = scope.launch {
            val app = application as TitanApp
            while (isActive) {
                val interval = maxOf(2, app.settings.captureIntervalSec) * 1000L
                try {
                    BubbleService.instance?.setCaptureHidden(true)   // a bolinha não aparece no print analisado
                    delay(150)
                    val bmp = grab()
                    BubbleService.instance?.setCaptureHidden(false)
                    if (bmp != null) { TitanState.lastBitmap = bmp; app.pipeline.processBitmap(bmp) }
                } catch (e: Exception) {
                    BubbleService.instance?.setCaptureHidden(false)
                    TitanState.error = "Erro na captura/análise: ${e.message}"
                }
                delay(interval)
            }
        }
    }

    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage() ?: return null
        try {
            val p = img.planes[0]
            val w = img.width; val h = img.height
            val rowPad = p.rowStride - p.pixelStride * w
            val full = Bitmap.createBitmap(w + rowPad / p.pixelStride, h, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(p.buffer)
            return if (rowPad == 0) full else Bitmap.createBitmap(full, 0, 0, w, h)
        } finally { img.close() }
    }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CH, "Captura TITAN", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 1, Intent(this, CaptureService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n: Notification = NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("TITAN está lendo a tela (autorizado)")
            .setContentText("Toque em Parar para encerrar a captura.")
            .addAction(0, "Parar", stop).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(2, n)
    }

    private fun shutdown() {
        if (closed) return
        closed = true
        loop?.cancel()
        try { display?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        display = null; reader = null; projection = null
        TitanState.captureActive = false
        TitanState.say("Captura de tela encerrada")
        BubbleService.instance?.setCaptureHidden(false)
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
