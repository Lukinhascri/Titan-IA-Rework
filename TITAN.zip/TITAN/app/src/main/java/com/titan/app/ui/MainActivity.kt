package com.titan.app.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.titan.app.TitanApp
import com.titan.app.core.DataOrigin
import com.titan.app.core.TitanState
import com.titan.app.data.Series
import com.titan.app.data.SeriesStore
import com.titan.app.data.TradeStats
import com.titan.app.floating.BubbleService
import com.titan.app.vision.CaptureService

class MainActivity : ComponentActivity() {
    private val app get() = application as TitanApp

    private val captureLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK && r.data != null) {
            ContextCompat.startForegroundService(this, CaptureService.intentStart(this, r.resultCode, r.data!!))
        } else TitanState.say("Captura de tela NÃO autorizada pelo usuário")
    }
    private val seriesPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri -> uri?.let { importSeries(it) } }
    private val calendarPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { u ->
            try {
                val (ok, bad) = contentResolver.openInputStream(u)!!.use { app.calendar.importCsv(it) }
                UiBus.message = "Calendário: $ok evento(s) importado(s), $bad linha(s) ignorada(s)."
            } catch (e: Exception) { UiBus.message = "Falha ao importar: ${e.message}" }
        }
    }
    private val tradesPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { u ->
            try {
                val (ok, bad) = contentResolver.openInputStream(u)!!.use { TradeStats.importTrades(app.db, it) }
                UiBus.message = "Operações reais: $ok importada(s), $bad linha(s) ignorada(s)."
                app.db.log("USUÁRIO", "IMPORT_TRADES", "$ok operações importadas")
            } catch (e: Exception) { UiBus.message = "Falha ao importar: ${e.message}" }
        }
    }

    private fun importSeries(u: Uri) {
        try {
            val (cs, bad) = contentResolver.openInputStream(u)!!.use { SeriesStore.parseCsv(it) }
            if (cs.isEmpty()) { UiBus.message = "Nenhuma vela válida no arquivo ($bad linha(s) ignorada(s))."; return }
            val asset = UiBus.importAsset.ifBlank { "ATIVO" }; val tf = UiBus.importTf.ifBlank { "M1" }
            SeriesStore.put(Series(asset, tf, DataOrigin.IMPORTADO, cs, System.currentTimeMillis()))
            UiBus.selectedKey = SeriesStore.key(asset, tf)
            UiBus.message = "Importadas ${cs.size} velas de $asset/$tf ($bad linha(s) ignorada(s))."
        } catch (e: Exception) { UiBus.message = "Falha ao importar: ${e.message}" }
    }

    private fun startBubble() {
        if (!Settings.canDrawOverlays(this)) {
            TitanState.say("Conceda 'Sobrepor a outros apps' ao TITAN e toque de novo em Ativar bolinha")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, BubbleService::class.java).setAction(BubbleService.ACTION_SHOW))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        val actions = Actions(
            startBubble = { startBubble() },
            stopBubble = { startService(Intent(this, BubbleService::class.java).setAction(BubbleService.ACTION_STOP)) },
            requestCapture = {
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                captureLauncher.launch(mpm.createScreenCaptureIntent())
            },
            stopCapture = { startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP)) },
            pickSeriesCsv = { seriesPicker.launch("*/*") },
            pickCalendarCsv = { calendarPicker.launch("*/*") },
            pickTradesCsv = { tradesPicker.launch("*/*") }
        )
        setContent { TitanTheme { Root(app, actions) } }
    }
}

private val TABS = listOf("Visão Geral", "Análise", "Estatísticas", "Radar", "Auto Trade", "Copilot", "Calendário", "Lab", "Histórico", "Config.")

@Composable
private fun Root(app: TitanApp, a: Actions) {
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().background(TitanColors.Bg).statusBarsPadding()) {
        ScrollableTabRow(selectedTabIndex = tab, edgePadding = 4.dp, containerColor = TitanColors.Surface, contentColor = TitanColors.Cyan) {
            TABS.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t, fontSize = 13.sp) }) }
        }
        when (tab) {
            0 -> OverviewScreen(app, a)
            1 -> AnalysisScreen(app, a)
            2 -> StatsScreen(app)
            3 -> RadarScreen(app)
            4 -> AutoTradeScreen(app)
            5 -> CopilotScreen()
            6 -> CalendarScreen(app, a)
            7 -> LabScreen(app)
            8 -> HistoryScreen(app, a)
            else -> SettingsScreen(app)
        }
    }
}
