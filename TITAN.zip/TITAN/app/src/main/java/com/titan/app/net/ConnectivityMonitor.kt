package com.titan.app.net

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.TrafficStats
import android.os.Process
import com.titan.app.core.TitanState
import kotlinx.coroutines.*
import java.net.HttpURLConnection
import java.net.URL

/**
 * Monitor de rede (Wi-Fi, 4G, 5G, qualquer operadora — o app só depende de internet, não da operadora).
 * Mede latência, reconecta com backoff exponencial e contabiliza dados usados pelo app.
 */
class ConnectivityMonitor(private val ctx: Context) {
    private val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private val baseBytes = TrafficStats.getUidRxBytes(Process.myUid()) + TrafficStats.getUidTxBytes(Process.myUid())

    private val cb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { refreshType(); TitanState.say("Rede disponível: ${TitanState.netType}") }
        override fun onLost(network: Network) { TitanState.connected = false; TitanState.latencyMs = null; TitanState.netType = "sem rede"; TitanState.say("Conexão perdida") }
        override fun onCapabilitiesChanged(network: Network, nc: NetworkCapabilities) { refreshType() }
    }

    private fun refreshType() {
        val nc = cm.getNetworkCapabilities(cm.activeNetwork)
        TitanState.netType = when {
            nc == null -> "sem rede"
            nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Celular (4G/5G)"
            nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "outra"
        }
    }

    fun start() {
        try { cm.registerNetworkCallback(NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(), cb) } catch (_: Exception) {}
        refreshType()
        job?.cancel()
        job = scope.launch {
            var backoff = 2_000L
            while (isActive) {
                val ms = measureLatency()
                if (ms != null) {
                    TitanState.connected = true; TitanState.latencyMs = ms; backoff = 2_000L
                    delay(15_000L)       // modo econômico: 1 ping leve a cada 15 s
                } else {
                    TitanState.connected = false; TitanState.latencyMs = null
                    delay(backoff); backoff = minOf(backoff * 2, 60_000L)    // reconexão automática com backoff
                }
                val now = TrafficStats.getUidRxBytes(Process.myUid()) + TrafficStats.getUidTxBytes(Process.myUid())
                if (baseBytes >= 0 && now >= 0) TitanState.dataUsedKb = (now - baseBytes) / 1024
            }
        }
    }

    fun stop() { job?.cancel(); try { cm.unregisterNetworkCallback(cb) } catch (_: Exception) {} }

    /** Latência em ms até um endpoint público leve (HTTP 204). null = sem conexão/timeout. */
    suspend fun measureLatency(): Long? = withContext(Dispatchers.IO) {
        try {
            val t0 = System.nanoTime()
            val c = URL("https://connectivitycheck.gstatic.com/generate_204").openConnection() as HttpURLConnection
            c.connectTimeout = 4000; c.readTimeout = 4000; c.requestMethod = "GET"
            val code = c.responseCode; c.disconnect()
            if (code in 200..399) (System.nanoTime() - t0) / 1_000_000 else null
        } catch (_: Exception) { null }
    }
}
