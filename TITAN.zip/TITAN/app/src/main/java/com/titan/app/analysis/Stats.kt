package com.titan.app.analysis

import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

object Stats {
    /** Intervalo de Wilson 95% para uma proporção. Retorna (low, high). */
    fun wilson(wins: Int, n: Int, z: Double = 1.96): Pair<Double, Double> {
        if (n == 0) return 0.0 to 1.0
        val p = wins.toDouble() / n
        val d = 1 + z * z / n
        val centre = p + z * z / (2 * n)
        val adj = z * sqrt((p * (1 - p) + z * z / (4 * n)) / n)
        return max(0.0, (centre - adj) / d) to min(1.0, (centre + adj) / d)
    }

    /** Taxa de acerto mínima para empatar com payout líquido p (ex.: 0,80 -> 55,6%). */
    fun breakEven(payout: Double) = 1.0 / (1.0 + payout)
}
