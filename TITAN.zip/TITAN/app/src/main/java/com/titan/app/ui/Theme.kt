package com.titan.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.titan.app.core.Candle

object TitanColors {
    val Bg = Color(0xFF0A0E1A); val Surface = Color(0xFF121829); val Surface2 = Color(0xFF1A2138)
    val Blue = Color(0xFF2D7BFF); val Purple = Color(0xFF8B5CF6); val Cyan = Color(0xFF22D3EE)
    val Green = Color(0xFF22C55E); val Red = Color(0xFFEF4444); val Amber = Color(0xFFF59E0B); val Muted = Color(0xFF94A3B8)
}

@Composable
fun TitanTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = TitanColors.Blue, secondary = TitanColors.Purple, tertiary = TitanColors.Cyan,
            background = TitanColors.Bg, surface = TitanColors.Surface, onSurface = Color(0xFFE2E8F0),
            onBackground = Color(0xFFE2E8F0), surfaceVariant = TitanColors.Surface2
        ), content = content
    )
}

@Composable
fun TCard(title: String? = null, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth().padding(vertical = 5.dp),
        colors = CardDefaults.cardColors(containerColor = TitanColors.Surface),
        border = BorderStroke(1.dp, Brush.horizontalGradient(listOf(TitanColors.Blue.copy(alpha = .5f), TitanColors.Purple.copy(alpha = .5f)))),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (title != null) Text(title, fontWeight = FontWeight.Bold, color = TitanColors.Cyan, fontSize = 15.sp)
            content()
        }
    }
}

@Composable
fun Pill(text: String, color: Color) {
    Box(Modifier.background(color.copy(alpha = .18f), RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 3.dp)) {
        Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun Muted(text: String) = Text(text, color = TitanColors.Muted, fontSize = 12.sp)

@Composable
fun KV(k: String, v: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(k, color = TitanColors.Muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(v, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.End)
    }
}

@Composable
fun Warn(text: String) {
    Row(Modifier.fillMaxWidth().background(TitanColors.Amber.copy(alpha = .12f), RoundedCornerShape(8.dp)).padding(8.dp)) {
        Text("⚠ $text", color = TitanColors.Amber, fontSize = 12.sp)
    }
}

/** Gráfico de velas simples (últimas n velas). */
@Composable
fun CandleChart(candles: List<Candle>, modifier: Modifier = Modifier, n: Int = 80) {
    val cs = candles.takeLast(n)
    Canvas(modifier.fillMaxWidth().height(170.dp).background(TitanColors.Bg, RoundedCornerShape(8.dp))) {
        if (cs.size < 2) return@Canvas
        val hi = cs.maxOf { it.h }; val lo = cs.minOf { it.l }
        val rng = (hi - lo).takeIf { it > 0 } ?: 1.0
        val w = size.width / cs.size
        fun y(p: Double) = (size.height * (1 - (p - lo) / rng)).toFloat()
        cs.forEachIndexed { i, c ->
            val x = i * w + w / 2
            val col = if (c.c >= c.o) TitanColors.Green else TitanColors.Red
            drawLine(col, Offset(x, y(c.h)), Offset(x, y(c.l)), strokeWidth = 1.5f)
            val top = y(maxOf(c.o, c.c)); val bot = y(minOf(c.o, c.c))
            drawRect(col, Offset(x - w * 0.35f, top), Size(w * 0.7f, maxOf(2f, bot - top)))
        }
    }
}

@Composable
fun TButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Button(onClick = onClick, enabled = enabled, modifier = modifier, shape = RoundedCornerShape(10.dp)) { Text(text, fontSize = 13.sp) }
}

@Composable
fun TOutline(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    OutlinedButton(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(10.dp)) { Text(text, fontSize = 13.sp) }
}

@Composable
fun TField(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier) {
    OutlinedTextField(value = value, onValueChange = onChange, label = { Text(label, fontSize = 12.sp) },
        modifier = modifier.fillMaxWidth(), singleLine = true)
}

@Composable
fun Logo(modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(38.dp).background(Brush.linearGradient(listOf(TitanColors.Blue, TitanColors.Purple)), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center) { Text("T", fontWeight = FontWeight.Black, fontSize = 22.sp, color = Color.White) }
        Column {
            Text("TITAN", fontWeight = FontWeight.Black, fontSize = 22.sp, color = Color.White, letterSpacing = 4.sp)
            Text("análise técnica assistida", fontSize = 11.sp, color = TitanColors.Muted)
        }
    }
}
