package com.titan.app.autotrade

import com.titan.app.core.Bias
import com.titan.app.core.Decision
import com.titan.app.core.SignalKind
import com.titan.app.data.Db
import com.titan.app.data.Settings
import com.titan.app.data.SimTrade
import com.titan.app.risk.RiskManager

data class PaperConfig(
    val strategyLabel: String = "TITAN Decision Engine",
    val requireKind: SignalKind = SignalKind.CONFIRMACAO,   // critério de entrada simulado
    val expirySec: Int = 60
)

/**
 * Paper trading: opera SOMENTE em simulação. Não existe nenhum código de envio de ordens reais,
 * nem de login/senha de corretora. Toda decisão é registrada no log de auditoria.
 */
class PaperTrader(private val db: Db, private val settings: Settings, private val risk: RiskManager) {
    var running = false
        private set

    fun start() { running = true; db.log("USUÁRIO", "AUTO_SIM_START", "Simulação iniciada") }
    fun stop() { running = false; db.log("USUÁRIO", "AUTO_SIM_STOP", "Simulação encerrada") }

    /** Abre operação simulada se a decisão atende ao critério e o risco permite. Retorna mensagem. */
    fun onDecision(d: Decision, price: Double?, cfg: PaperConfig): String {
        if (!running) return "Simulação pausada"
        if (price == null) return "Sem preço atual: operação simulada não aberta"
        if (d.bias == Bias.NEUTRO || d.kind == SignalKind.AUSENCIA_DE_SINAL) return "Sem sinal"
        val need = if (cfg.requireKind == SignalKind.CONFIRMACAO) d.kind == SignalKind.CONFIRMACAO else true
        if (!need) return "Sinal não atinge o critério de entrada configurado (${cfg.requireKind})"
        val rs = risk.status()
        if (!rs.allowed) {
            db.log("SISTEMA", "BLOQUEIO_RISCO", rs.reasons.joinToString("; "))
            return "BLOQUEADO: " + rs.reasons.joinToString("; ")
        }
        if (db.trades(source = "SIM").any { it.closedAt == null && it.asset == d.asset }) return "Já existe operação simulada aberta neste ativo"
        val id = db.insertTrade(SimTrade(0, System.currentTimeMillis(), null, d.asset, d.timeframe, cfg.strategyLabel,
            if (d.bias == Bias.ALTA) 1 else -1, price, null, settings.stake.toDouble(), settings.payout.toDouble(),
            cfg.expirySec, null, null, "SIM"))
        db.log("SISTEMA", "TRADE_SIM_ABERTO", "#$id ${d.asset} ${d.bias} @ $price (${d.kind})")
        return "Operação simulada #$id aberta (${d.bias})"
    }

    /** Resolve operações cujo prazo expirou usando o preço atual lido. */
    fun resolveDue(asset: String, price: Double, now: Long = System.currentTimeMillis()): Int {
        var n = 0
        for (t in db.trades(source = "SIM").filter { it.closedAt == null && it.asset == asset }) {
            if (now - t.openedAt < t.expirySec * 1000L) continue
            val win = (price > t.entry && t.direction > 0) || (price < t.entry && t.direction < 0)
            val tie = price == t.entry
            val (res, pl) = when {
                tie -> "TIE" to 0.0
                win -> "WIN" to t.stake * t.payout
                else -> "LOSS" to -t.stake
            }
            db.closeTrade(t.id, price, res, pl, now)
            db.log("SISTEMA", "TRADE_SIM_FECHADO", "#${t.id} $res pl=${"%.2f".format(pl)}")
            n++
        }
        return n
    }
}
