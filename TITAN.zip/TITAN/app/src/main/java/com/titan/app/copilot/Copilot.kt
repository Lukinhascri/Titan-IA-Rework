package com.titan.app.copilot

import com.titan.app.core.Decision
import com.titan.app.core.TitanState

/**
 * TITAN Copilot: assistente por REGRAS. Não é um LLM e não acessa a internet:
 * responde apenas com (a) glossário embutido e (b) dados que já estão no app (última análise, alerta, estatísticas).
 */
object Copilot {
    private val glossary = linkedMapOf(
        "rsi" to "RSI (Índice de Força Relativa, 0–100): compara ganhos e perdas recentes. Abaixo de 30 costuma indicar sobrevenda e acima de 70 sobrecompra, mas em tendência forte pode ficar nessas zonas por muito tempo.",
        "macd" to "MACD: diferença entre EMA12 e EMA26, com linha de sinal (EMA9). Cruzamento da linha sobre o sinal sugere mudança de momentum; o histograma mostra a distância entre as duas.",
        "ema" to "EMA: média móvel exponencial, dá mais peso aos preços recentes. Cruzamento de EMA curta sobre longa é um sinal de tendência clássico, com atraso.",
        "sma" to "SMA: média móvel simples dos últimos N fechamentos.",
        "vwap" to "VWAP: preço médio ponderado pelo volume. Exige dados de volume; sem volume o TITAN não calcula.",
        "bollinger" to "Bandas de Bollinger: média de 20 períodos ± 2 desvios-padrão. Preço fora da banda indica movimento esticado, não reversão garantida.",
        "atr" to "ATR: média da amplitude real das velas; mede volatilidade, não direção.",
        "adx" to "ADX: força da tendência (não a direção). Abaixo de ~20 o mercado tende a ser lateral.",
        "estoc" to "Estocástico: posição do fechamento dentro da faixa recente (0–100). %K cruzando %D em extremos gera sinais de reversão.",
        "cci" to "CCI: desvio do preço típico em relação à média; acima de +100 / abaixo de −100 indica movimento estendido.",
        "obv" to "OBV: soma volume nas altas e subtrai nas baixas; precisa de volume.",
        "ichimoku" to "Ichimoku: Tenkan/Kijun e a nuvem (Senkou A/B). Preço acima da nuvem = viés de alta; abaixo = viés de baixa.",
        "sar" to "Parabolic SAR: pontos que seguem o preço; a troca de lado sinaliza possível virada de tendência.",
        "fibonacci" to "Fibonacci: retrações (23,6%, 38,2%, 50%, 61,8%, 78,6%) da última perna do movimento, usadas como zonas de reação.",
        "pivot" to "Pivot Points: níveis calculados com máxima, mínima e fechamento anteriores (P, R1, S1...).",
        "doji" to "Doji: abertura ≈ fechamento; indica indecisão.",
        "martelo" to "Martelo: corpo pequeno e sombra inferior longa após queda; possível reversão de alta.",
        "engolfo" to "Engolfo: a vela atual cobre o corpo da anterior em sentido oposto; reversão possível.",
        "harami" to "Harami: corpo pequeno contido no corpo da vela anterior; perda de momentum.",
        "marubozu" to "Marubozu: vela com corpo quase sem sombras; pressão forte em uma direção.",
        "price action" to "Price Action: leitura direta de velas, estruturas e níveis, sem depender de muitos indicadores.",
        "smc" to "SMC/ICT: o TITAN usa apenas conceitos objetivos — quebra de estrutura (BOS), varredura de liquidez e gaps de valor justo (FVG).",
        "wyckoff" to "Wyckoff e Ondas de Elliott NÃO estão automatizados no TITAN: exigem interpretação subjetiva e eu não vou fingir que funcionam.",
        "dow" to "Teoria de Dow: tendência de alta = topos e fundos ascendentes; baixa = descendentes.",
        "expira" to "Tempo de expiração é o prazo configurado da operação; tempo restante da vela é o relógio da vela atual. São coisas diferentes e o TITAN tenta lê-las separadamente.",
        "backtest" to "Backtest: simula a regra no passado. Sinal no fechamento, entrada na abertura seguinte, sem dados futuros. Resultado passado não garante futuro.",
        "overfitting" to "Overfitting: ajustar a estratégia até 'acertar' o passado por acaso. Por isso o Lab mostra fora da amostra e walk-forward."
    )

    fun answer(q: String, d: Decision? = TitanState.lastDecision): String {
        val s = q.lowercase().trim()
        if (s.isBlank()) return "Pergunte sobre um indicador, padrão, o último alerta ou o cenário atual."
        if (listOf("por que", "porque", "motivo").any { s.contains(it) } && (s.contains("alerta") || s.contains("sinal"))) {
            val a = TitanState.liveAlert
            return if (a != null) "Alerta ${a.kind} em ${a.asset} (viés ${a.bias}). Critérios: ${a.criteria}. Isto é uma hipótese, não uma certeza."
            else if (d != null) "Não há alerta ativo. Última análise: ${d.explanation}"
            else "Ainda não há análise nem alerta para explicar."
        }
        if (s.contains("positiv") || s.contains("negativ") || s.contains("pontos")) {
            if (d == null) return "Sem análise recente."
            val ev = d.reports.flatMap { it.evidences }.filter { it.score != 0.0 }
            val pos = ev.filter { it.score > 0 }.joinToString("; ") { it.name + " (" + it.detail + ")" }.ifEmpty { "nenhum" }
            val neg = ev.filter { it.score < 0 }.joinToString("; ") { it.name + " (" + it.detail + ")" }.ifEmpty { "nenhum" }
            return "A favor da alta: $pos.\nA favor da baixa: $neg.\nAvisos: " + (d.reports.flatMap { it.warnings }.joinToString("; ").ifEmpty { "nenhum" })
        }
        if (s.contains("cenário") || s.contains("cenario") || s.contains("resumo") || s.contains("mercado")) {
            if (d == null) return "Sem análise recente. Faça uma captura ou importe dados e rode a análise."
            return "${d.asset} (${d.timeframe}): ${d.kind.name.replace('_', ' ')}, viés ${d.bias.name.lowercase()}, score ${"%.2f".format(d.score)}.\n" +
                d.reports.joinToString("\n") { "• ${it.module}: ${it.summary}" }
        }
        if (s.contains("estatíst") || s.contains("estatist") || s.contains("acerto")) {
            return "As estatísticas reais do app estão na aba Estatísticas (simulado e importado separados). Não invento números: se não houver operações fechadas, ela mostra zero."
        }
        if (s.contains("ajuda") || s.contains("o que você faz") || s.contains("como usar")) {
            return "Posso explicar indicadores, padrões, o último alerta, o cenário e os pontos positivos/negativos da análise. Tópicos: ${glossary.keys.joinToString(", ")}."
        }
        glossary.entries.firstOrNull { s.contains(it.key) }?.let { return it.value }
        return "Não encontrei isso nos dados do app nem no meu glossário. Tente: 'o que é RSI', 'por que o alerta', 'resumo do cenário' ou 'pontos positivos e negativos'."
    }
}
