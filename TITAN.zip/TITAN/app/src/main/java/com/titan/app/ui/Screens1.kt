package com.titan.app.ui

import android.os.SystemClock
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.titan.app.TitanApp
import com.titan.app.analysis.DecisionEngine
import com.titan.app.analysis.Timeframes
import com.titan.app.avalon.AvalonEngine
import com.titan.app.core.*
import com.titan.app.data.SeriesStore
import com.titan.app.data.TradeStats
import com.titan.app.patterns.CandlePatterns
import com.titan.app.patterns.ChartPatterns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class Actions(
    val startBubble: () -> Unit, val stopBubble: () -> Unit, val requestCapture: () -> Unit, val stopCapture: () -> Unit,
    val pickSeriesCsv: () -> Unit, val pickCalendarCsv: () -> Unit, val pickTradesCsv: () -> Unit
)

object UiBus {
    var importAsset by mutableStateOf("EURUSD")
    var importTf by mutableStateOf("M1")
    var message by mutableStateOf("")
    var selectedKey by mutableStateOf<String?>(null)
    var statsSource by mutableStateOf("SIM")
}

@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), content = content)
}

fun kindColor(k: SignalKind) = when (k) {
    SignalKind.CONFIRMACAO -> TitanColors.Green; SignalKind.OPORTUNIDADE -> TitanColors.Amber; else -> TitanColors.Muted
}

// ============ 1. VISÃO GERAL ============
@Composable
fun OverviewScreen(app: TitanApp, a: Actions) {
    var mode by remember { mutableStateOf(app.settings.mode) }
    var now by remember { mutableStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(Unit) { while (true) { now = SystemClock.elapsedRealtime(); delay(1000) } }
    val st = TitanState
    Page {
        Logo(Modifier.padding(bottom = 8.dp))
        TCard("Status") {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Pill(if (st.connected) "ONLINE" else "OFFLINE", if (st.connected) TitanColors.Green else TitanColors.Red)
                Pill(st.netType, TitanColors.Cyan)
                Pill(st.latencyMs?.let { "$it ms" } ?: "-- ms", TitanColors.Blue)
            }
            KV("Dados usados pelo app", "${st.dataUsedKb} KB")
            KV("Captura de tela", if (st.captureActive) "ATIVA (autorizada)" else "desligada")
            KV("Análise", if (st.analyzing) "em andamento" else "ociosa")
            st.error?.let { Warn(it) }
            if (!st.connected) Muted("Sem internet: leitura visual e análise local continuam, mas funções que dependem de dados externos não.")
        }
        TCard("Controles") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TButton("Ativar bolinha", a.startBubble, Modifier.weight(1f))
                TOutline("Fechar bolinha", a.stopBubble, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TButton("Autorizar captura", a.requestCapture, Modifier.weight(1f), enabled = !st.captureActive)
                TOutline("Parar captura", a.stopCapture, Modifier.weight(1f))
            }
            Muted("A captura usa o diálogo oficial do Android e mostra uma notificação enquanto estiver ativa.")
        }
        TCard("Modo de funcionamento") {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("INDEPENDENT" to "Independente", "VISUAL" to "Visual", "HYBRID" to "Híbrido").forEach { (k, l) ->
                    FilterChip(selected = mode == k, onClick = { mode = k; app.settings.mode = k }, label = { Text(l, fontSize = 12.sp) })
                }
            }
            Muted(when (mode) {
                "INDEPENDENT" -> "Analisa dados IMPORTADOS por você (CSV). Não há fonte automática da Avalon."
                "VISUAL" -> "Analisa o que aparece na tela (captura autorizada)."
                else -> "Compara a leitura visual com a série importada e sinaliza inconsistências."
            })
        }
        val r = st.lastRead
        TCard("Última leitura visual") {
            if (r == null) Muted("Nenhuma leitura ainda. Autorize a captura com o gráfico da Avalon aberto.")
            else {
                KV("Plataforma", r.platform ?: "não identificada")
                KV("Ativo", r.asset ?: "não identificado")
                KV("Tempo gráfico", r.timeframe ?: "não identificado")
                KV("Tipo de gráfico", r.chartType ?: "não identificado")
                KV("Preço atual", r.price?.toString() ?: "não lido")
                KV("Tempo restante da VELA", r.candleSecondsLeft?.let { "${it}s" } ?: "não lido")
                KV("Tempo de EXPIRAÇÃO", r.expirySeconds?.let { "${it}s" } ?: "não lido")
                KV("Velas extraídas", r.candles.size.toString())
                KV("Idade da leitura", "${(System.currentTimeMillis() - r.readAt) / 1000}s")
                r.notes.forEach { Muted("• $it") }
                if (r.candles.size > 2) CandleChart(r.candles)
            }
        }
        st.liveAlert?.let { al ->
            TCard("Alerta ativo") {
                Pill(al.kind.name.replace('_', ' '), kindColor(al.kind))
                KV("Ativo / viés", "${al.asset} / ${al.bias}")
                val left = al.targetElapsed?.let { (it - now) / 1000 }
                KV("Contagem regressiva", if (left == null) "sem relógio de vela lido" else if (left >= 0) "${left}s" else "vela já fechou (${-left}s atrás)")
                al.readAgeSec?.let { if (it > 5) Warn("Leitura com ${it}s de atraso: confirme na tela") }
                Muted(al.criteria)
                Muted("Hipótese baseada em dados passados — não é previsão nem garantia.")
            }
        }
        val avalon = AvalonEngine.assess(r)
        TCard("TITAN Avalon Engine") {
            KV("Modo de integração", avalon.integrationMode)
            KV("Plataforma Avalon reconhecida", if (avalon.platformDetected) "sim" else "não")
            KV("API oficial", if (AvalonEngine.OFFICIAL_API_FOUND) "sim" else "NÃO encontrada")
            avalon.limitations.forEach { Muted("• $it") }
        }
        TCard("Registro") { if (st.log.isEmpty()) Muted("Sem eventos.") else st.log.take(12).forEach { Muted(it) } }
        Muted("TITAN é uma ferramenta de apoio à análise. Não garante resultados e não executa operações reais.")
    }
}

// ============ 2. ANÁLISE ============
@Composable
fun AnalysisScreen(app: TitanApp, a: Actions) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    val list = SeriesStore.all()
    val sel = UiBus.selectedKey?.let { SeriesStore.map[it] }
    Page {
        TCard("Dados") {
            Muted("Importe um CSV (timestamp,open,high,low,close[,volume]) com o ativo/tempo abaixo, ou use a leitura visual.")
            TField(UiBus.importAsset, { UiBus.importAsset = it.uppercase() }, "Ativo (ex.: EURUSD)")
            TField(UiBus.importTf, { UiBus.importTf = it.uppercase() }, "Tempo gráfico (ex.: M1, M5, H1)")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TButton("Importar CSV", a.pickSeriesCsv, Modifier.weight(1f))
                TOutline("Dados DEMO", {
                    SeriesStore.put(com.titan.app.data.Series("DEMO", "M1", DataOrigin.SINTETICO_DEMO, SeriesStore.synthetic(), System.currentTimeMillis()))
                    UiBus.message = "Série SINTÉTICA criada (apenas teste; nunca usada em estatísticas)."
                }, Modifier.weight(1f))
            }
            if (UiBus.message.isNotEmpty()) Muted(UiBus.message)
        }
        TCard("Séries disponíveis") {
            if (list.isEmpty()) Muted("Nenhuma série. Importe um CSV, crie a DEMO ou capture a tela.")
            list.forEach { s ->
                val key = SeriesStore.key(s.asset, s.timeframe)
                Row(Modifier.fillMaxWidth().clickable { UiBus.selectedKey = key }.padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text((if (key == UiBus.selectedKey) "▶ " else "") + "${s.asset} · ${s.timeframe}", fontSize = 14.sp)
                    Pill("${s.origin.name} · ${s.candles.size}", when (s.origin) { DataOrigin.SINTETICO_DEMO -> TitanColors.Amber; DataOrigin.VISUAL -> TitanColors.Cyan; else -> TitanColors.Green })
                }
            }
            TButton(if (busy) "Analisando…" else "Analisar série selecionada", {
                val s = sel ?: return@TButton
                busy = true
                scope.launch {
                    withContext(Dispatchers.Default) {
                        val tf = s.timeframe.removeSuffix("·visual")
                        app.pipeline.analyze(s.asset, tf, s.origin, s.candles, if (s.origin == DataOrigin.VISUAL) TitanState.lastRead else null)
                    }
                    busy = false
                }
            }, enabled = sel != null && !busy)
        }
        if (sel != null) CandleChart(sel.candles)
        TitanState.lastDecision?.let { DecisionView(it) } ?: Muted("Selecione uma série e toque em Analisar.")
    }
}

@Composable
fun DecisionView(d: Decision) {
    TCard("Decisão — ${d.asset} (${d.timeframe})") {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Pill(d.kind.name.replace('_', ' '), kindColor(d.kind))
            Pill("viés ${d.bias.name}", if (d.bias == Bias.ALTA) TitanColors.Green else if (d.bias == Bias.BAIXA) TitanColors.Red else TitanColors.Muted)
        }
        KV("Score combinado", "%.2f".format(d.score))
        KV("Confiança estatística", d.statConfidence?.let { "${(it * 100).toInt()}% (limite inf. 95%, n=${d.sampleSize})" } ?: "indisponível (amostra insuficiente)")
        Text(d.explanation, fontSize = 13.sp)
        Muted("Critérios atendidos: " + d.criteriaMet.ifEmpty { listOf("nenhum") }.joinToString("; "))
        if (d.criteriaMissing.isNotEmpty()) Muted("Faltam: " + d.criteriaMissing.joinToString("; "))
    }
    d.reports.forEach { r ->
        var open by remember(r.module, d.createdAt) { mutableStateOf(false) }
        TCard(r.module) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Pill("qualidade ${(r.quality * 100).toInt()}%", if (r.quality >= .5) TitanColors.Green else TitanColors.Red)
                if (r.score != 0.0) Pill("score %.2f".format(r.score), if (r.score > 0) TitanColors.Green else TitanColors.Red)
            }
            Text(r.summary, fontSize = 13.sp)
            r.warnings.forEach { Warn(it) }
            if (r.evidences.isNotEmpty()) {
                TOutline(if (open) "Ocultar evidências" else "Ver evidências (${r.evidences.size})", { open = !open })
                if (open) r.evidences.forEach { e -> Muted("• ${e.name}${if (e.score != 0.0) " [%+.2f]".format(e.score) else ""}: ${e.detail}") }
            }
        }
    }
    Muted("A concordância entre módulos não é garantia de acerto.")
}

// ============ 3. ESTATÍSTICAS ============
@Composable
fun StatsScreen(app: TitanApp) {
    val src = UiBus.statsSource
    val trades = remember(src, TitanState.paperMessage, UiBus.message) { app.db.trades(source = src) }
    val s = remember(trades) { TradeStats.summarize(trades) }
    Page {
        TCard("Origem dos dados") {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = src == "SIM", onClick = { UiBus.statsSource = "SIM" }, label = { Text("SIMULADO") })
                FilterChip(selected = src == "IMPORT", onClick = { UiBus.statsSource = "IMPORT" }, label = { Text("REAL IMPORTADO") })
            }
            Muted("Dados simulados e reais importados NUNCA são misturados. Dados sintéticos de demonstração não entram aqui.")
        }
        TCard("Resumo (${if (src == "SIM") "simulado" else "real importado"})") {
            KV("Operações fechadas", s.total.toString()); KV("Vitórias", s.wins.toString()); KV("Derrotas", s.losses.toString()); KV("Empates", s.ties.toString())
            KV("Taxa de acerto (sem empates)", if (s.wins + s.losses == 0) "—" else "${"%.1f".format(s.winRate * 100)}%")
            KV("Lucro/prejuízo", "%.2f".format(s.pl))
            KV("Maior sequência de vitórias", s.longestWin.toString()); KV("Maior sequência de derrotas", s.longestLoss.toString())
            if (s.total == 0) Muted("Sem operações fechadas ainda: nada a mostrar (o TITAN não inventa números).")
            if (s.total in 1..29) Warn("Amostra pequena (${s.total}): a taxa de acerto é pouco confiável.")
        }
        listOf("Por ativo" to s.byAsset, "Por estratégia" to s.byStrategy, "Por tempo gráfico" to s.byTimeframe,
            "Por dia" to s.byDay, "Por semana" to s.byWeek, "Por mês" to s.byMonth).forEach { (t, g) ->
            if (g.isNotEmpty()) TCard(t) {
                g.takeLast(15).forEach { x -> KV(x.key, "${x.trades} op · ${x.wins}V/${x.losses}D/${x.ties}E · ${"%.0f".format(x.winRate * 100)}% · ${"%.2f".format(x.pl)}") }
            }
        }
        if (s.byStrategy.size > 1) TCard("Memória: comparação entre métodos") {
            s.byStrategy.sortedByDescending { it.winRate }.forEach { KV(it.key, "${"%.0f".format(it.winRate * 100)}% em ${it.trades} op") }
            Warn("Ranking informativo. Nenhuma estratégia é alterada automaticamente: qualquer ajuste deve ser validado no TITAN Lab antes de uso.")
        }
    }
}

// ============ 4. RADAR ============
data class RadarRow(val asset: String, val tf: String, val origin: DataOrigin, val d: Decision, val trend: String, val vol: String,
                    val patterns: String, val quality: Double, val risk: String, val rank: Double)

@Composable
fun RadarScreen(app: TitanApp) {
    val scope = rememberCoroutineScope()
    var rows by remember { mutableStateOf<List<RadarRow>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    Page {
        TCard("Radar de Oportunidades") {
            Muted("Monitora os ativos que o TITAN já viu (captura/CSV). A lista de ativos da Avalon não é acessível sem API oficial.")
            Muted("Ranking = 60% critérios atendidos (7 critérios que incluem multi-tempo e estatística) + 20% qualidade dos dados + 20% confiança estatística. Não é uma contagem de indicadores.")
            TButton(if (busy) "Calculando…" else "Atualizar radar", {
                busy = true
                scope.launch {
                    rows = withContext(Dispatchers.Default) {
                        SeriesStore.all().filter { it.candles.size >= 30 }.map { s ->
                            val tf = s.timeframe.removeSuffix("·visual")
                            val d = DecisionEngine.decide(s.asset, tf, s.candles, s.origin, null, app.pipeline.config())
                            val mkt = d.reports.first { it.module == "TITAN Market Analyst" }
                            val aud = d.reports.first { it.module == "TITAN Auditor" }
                            val pats = (CandlePatterns.detect(s.candles, 3).map { it.name } + ChartPatterns.detect(s.candles).map { it.name }).distinct()
                            val total = (d.criteriaMet.size + d.criteriaMissing.size).coerceAtLeast(1)
                            val rank = 60.0 * d.criteriaMet.size / total + 20.0 * aud.quality + 20.0 * (d.statConfidence ?: 0.0)
                            val risk = when {
                                aud.quality < .5 || mkt.warnings.any { it.contains("extrema") } -> "ALTO"
                                d.criteriaMissing.size >= 3 -> "MÉDIO" else -> "BAIXO"
                            }
                            RadarRow(s.asset, tf, s.origin, d, mkt.summary.substringBefore('.'),
                                mkt.evidences.firstOrNull { it.name == "Volatilidade" }?.detail ?: "n/d",
                                pats.joinToString().ifEmpty { "nenhum" }, aud.quality, risk, if (s.origin == DataOrigin.SINTETICO_DEMO) -1.0 else rank)
                        }.sortedByDescending { it.rank }
                    }
                    busy = false
                }
            }, enabled = !busy)
        }
        if (rows.isEmpty()) Muted("Sem ativos com 30+ velas. Importe dados ou capture a tela.")
        rows.forEach { r ->
            TCard("${r.asset} · ${r.tf}") {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Pill(r.d.kind.name.replace('_', ' '), kindColor(r.d.kind)); Pill("risco ${r.risk}", if (r.risk == "ALTO") TitanColors.Red else if (r.risk == "MÉDIO") TitanColors.Amber else TitanColors.Green)
                    Pill(r.origin.name, TitanColors.Muted)
                }
                KV("Tendência", r.trend); KV("Volatilidade", r.vol); KV("Padrões", r.patterns)
                KV("Qualidade dos dados", "${(r.quality * 100).toInt()}%")
                KV("Critérios atendidos", "${r.d.criteriaMet.size}/${r.d.criteriaMet.size + r.d.criteriaMissing.size}")
                KV("Ranking", if (r.rank < 0) "excluído (dados DEMO)" else "%.0f".format(r.rank))
                if (r.d.criteriaMissing.isNotEmpty()) Muted("Faltam: " + r.d.criteriaMissing.joinToString("; "))
            }
        }
    }
}
