package com.titan.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class SimTrade(
    val id: Long, val openedAt: Long, val closedAt: Long?, val asset: String, val timeframe: String,
    val strategy: String, val direction: Int, val entry: Double, val exit: Double?, val stake: Double,
    val payout: Double, val expirySec: Int, val result: String?, val pl: Double?, val source: String
)

data class AlertRow(
    val id: Long, val createdAt: Long, val asset: String, val kind: String, val bias: String,
    val targetTime: Long?, val criteria: String, val status: String, val note: String
)

data class EventRow(
    val id: Long, val time: Long, val country: String, val title: String, val importance: Int,
    val sourceName: String, val sourceDate: String
)

/** Banco local (SQLite). source: "SIM" (paper trading) ou "IMPORT" (dados reais importados pelo usuário). */
class Db(ctx: Context) : SQLiteOpenHelper(ctx, "titan.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE trades(id INTEGER PRIMARY KEY AUTOINCREMENT, opened_at INTEGER, closed_at INTEGER,
            asset TEXT, timeframe TEXT, strategy TEXT, direction INTEGER, entry REAL, exit REAL, stake REAL,
            payout REAL, expiry_sec INTEGER, result TEXT, pl REAL, source TEXT)""")
        db.execSQL("""CREATE TABLE analyses(id INTEGER PRIMARY KEY AUTOINCREMENT, at INTEGER, asset TEXT, timeframe TEXT,
            origin TEXT, bias TEXT, kind TEXT, score REAL, stat_conf REAL, sample INTEGER, explanation TEXT)""")
        db.execSQL("""CREATE TABLE alerts(id INTEGER PRIMARY KEY AUTOINCREMENT, created_at INTEGER, asset TEXT, kind TEXT,
            bias TEXT, target_time INTEGER, criteria TEXT, status TEXT, note TEXT)""")
        db.execSQL("CREATE TABLE audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT, at INTEGER, actor TEXT, action TEXT, detail TEXT)")
        db.execSQL("""CREATE TABLE events(id INTEGER PRIMARY KEY AUTOINCREMENT, time INTEGER, country TEXT, title TEXT,
            importance INTEGER, source_name TEXT, source_date TEXT)""")
        db.execSQL("""CREATE TABLE series(asset TEXT, timeframe TEXT, origin TEXT, t INTEGER, o REAL, h REAL, l REAL, c REAL, v REAL)""")
        db.execSQL("CREATE INDEX idx_series ON series(asset, timeframe)")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) { /* v1: sem migrações */ }

    // ---------- trades ----------
    fun insertTrade(t: SimTrade): Long = writableDatabase.insert("trades", null, ContentValues().apply {
        put("opened_at", t.openedAt); put("closed_at", t.closedAt); put("asset", t.asset); put("timeframe", t.timeframe)
        put("strategy", t.strategy); put("direction", t.direction); put("entry", t.entry); put("exit", t.exit)
        put("stake", t.stake); put("payout", t.payout); put("expiry_sec", t.expirySec); put("result", t.result)
        put("pl", t.pl); put("source", t.source)
    })

    fun closeTrade(id: Long, exit: Double, result: String, pl: Double, at: Long) {
        writableDatabase.update("trades", ContentValues().apply {
            put("exit", exit); put("result", result); put("pl", pl); put("closed_at", at)
        }, "id=?", arrayOf(id.toString()))
    }

    fun trades(source: String? = null, onlyClosed: Boolean = false): List<SimTrade> {
        val where = mutableListOf<String>(); val args = mutableListOf<String>()
        if (source != null) { where += "source=?"; args += source }
        if (onlyClosed) where += "closed_at IS NOT NULL"
        val out = mutableListOf<SimTrade>()
        readableDatabase.query("trades", null, where.joinToString(" AND ").ifEmpty { null },
            args.toTypedArray().ifEmpty { null }, null, null, "opened_at DESC").use { c ->
            while (c.moveToNext()) out += SimTrade(
                c.getLong(0), c.getLong(1), if (c.isNull(2)) null else c.getLong(2), c.getString(3), c.getString(4),
                c.getString(5), c.getInt(6), c.getDouble(7), if (c.isNull(8)) null else c.getDouble(8), c.getDouble(9),
                c.getDouble(10), c.getInt(11), c.getString(12), if (c.isNull(13)) null else c.getDouble(13), c.getString(14))
        }
        return out
    }

    // ---------- análises ----------
    fun insertAnalysis(asset: String, tf: String, origin: String, bias: String, kind: String, score: Double,
                       conf: Double?, sample: Int, expl: String) {
        writableDatabase.insert("analyses", null, ContentValues().apply {
            put("at", System.currentTimeMillis()); put("asset", asset); put("timeframe", tf); put("origin", origin)
            put("bias", bias); put("kind", kind); put("score", score); put("stat_conf", conf); put("sample", sample)
            put("explanation", expl)
        })
    }

    fun recentAnalyses(limit: Int = 50): List<List<String>> {
        val out = mutableListOf<List<String>>()
        readableDatabase.query("analyses", null, null, null, null, null, "at DESC", limit.toString()).use { c ->
            while (c.moveToNext()) out += listOf(c.getLong(1).toString(), c.getString(2), c.getString(3), c.getString(4),
                c.getString(5), c.getString(6), c.getString(10))
        }
        return out
    }

    // ---------- alertas ----------
    fun insertAlert(a: AlertRow): Long = writableDatabase.insert("alerts", null, ContentValues().apply {
        put("created_at", a.createdAt); put("asset", a.asset); put("kind", a.kind); put("bias", a.bias)
        put("target_time", a.targetTime); put("criteria", a.criteria); put("status", a.status); put("note", a.note)
    })

    fun updateAlert(id: Long, status: String, note: String) {
        writableDatabase.update("alerts", ContentValues().apply { put("status", status); put("note", note) },
            "id=?", arrayOf(id.toString()))
    }

    fun alerts(limit: Int = 100): List<AlertRow> {
        val out = mutableListOf<AlertRow>()
        readableDatabase.query("alerts", null, null, null, null, null, "created_at DESC", limit.toString()).use { c ->
            while (c.moveToNext()) out += AlertRow(c.getLong(0), c.getLong(1), c.getString(2), c.getString(3), c.getString(4),
                if (c.isNull(5)) null else c.getLong(5), c.getString(6), c.getString(7), c.getString(8))
        }
        return out
    }

    // ---------- auditoria de decisões ----------
    fun log(actor: String, action: String, detail: String) {
        writableDatabase.insert("audit_log", null, ContentValues().apply {
            put("at", System.currentTimeMillis()); put("actor", actor); put("action", action); put("detail", detail)
        })
    }

    fun auditLog(limit: Int = 100): List<List<String>> {
        val out = mutableListOf<List<String>>()
        readableDatabase.query("audit_log", null, null, null, null, null, "at DESC", limit.toString()).use { c ->
            while (c.moveToNext()) out += listOf(c.getLong(1).toString(), c.getString(2), c.getString(3), c.getString(4))
        }
        return out
    }

    // ---------- calendário ----------
    fun insertEvent(e: EventRow) {
        writableDatabase.insert("events", null, ContentValues().apply {
            put("time", e.time); put("country", e.country); put("title", e.title); put("importance", e.importance)
            put("source_name", e.sourceName); put("source_date", e.sourceDate)
        })
    }

    fun events(fromMillis: Long): List<EventRow> {
        val out = mutableListOf<EventRow>()
        readableDatabase.query("events", null, "time>=?", arrayOf(fromMillis.toString()), null, null, "time ASC").use { c ->
            while (c.moveToNext()) out += EventRow(c.getLong(0), c.getLong(1), c.getString(2), c.getString(3), c.getInt(4),
                c.getString(5), c.getString(6))
        }
        return out
    }

    fun clearEvents() { writableDatabase.delete("events", null, null) }
}
