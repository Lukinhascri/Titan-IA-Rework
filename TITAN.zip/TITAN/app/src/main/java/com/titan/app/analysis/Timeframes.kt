package com.titan.app.analysis

import com.titan.app.core.Bias
import com.titan.app.core.Candle
import com.titan.app.indicators.Indicators
import com.titan.app.indicators.closes
import com.titan.app.indicators.lastValid
import com.titan.app.strategies.MarketStructure

object Timeframes {
    /** Converte "M5", "5m", "H1", "1h", "15 min" em minutos; null se desconhecido. */
    fun minutes(label: String?): Int? {
        if (label == null) return null
        val s = label.trim().lowercase().replace(" ", "")
        Regex("^m(\\d+)$").find(s)?.let { return it.groupValues[1].toInt() }
        Regex("^h(\\d+)$").find(s)?.let { return it.groupValues[1].toInt() * 60 }
        Regex("^(\\d+)(m|min|mins|minuto|minutos)$").find(s)?.let { return it.groupValues[1].toInt() }
        Regex("^(\\d+)(h|hr|hora|horas)$").find(s)?.let { return it.groupValues[1].toInt() * 60 }
        return null
    }

    fun label(min: Int) = if (min % 60 == 0 && min >= 60) "${min / 60}h" else "${min}m"

    fun aggregate(cs: List<Candle>, factor: Int): List<Candle> {
        if (factor <= 1) return cs
        val out = mutableListOf<Candle>()
        var i = 0
        while (i + factor <= cs.size) {
            val g = cs.subList(i, i + factor)
            out += Candle(g.first().t, g.first().o, g.maxOf { it.h }, g.minOf { it.l }, g.last().c, g.sumOf { it.v })
            i += factor
        }
        return out
    }
}

data class TfTrend(val label: String, val bias: Bias, val candles: Int, val note: String)

data class MtfResult(
    val trends: List<TfTrend>,
    val primary: Bias,
    val secondary: Bias,
    val confluence: Double,            // -1..+1
    val disagreements: List<String>,
    val note: String
)

object MultiTimeframe {
    private val targets = listOf(1, 5, 15, 30, 60)

    fun analyze(cs: List<Candle>, baseMinutes: Int?): MtfResult {
        if (baseMinutes == null) {
            return MtfResult(emptyList(), Bias.NEUTRO, Bias.NEUTRO, 0.0, emptyList(),
                "Tempo gráfico desconhecido: não é possível comparar períodos.")
        }
        val trends = mutableListOf<TfTrend>()
        for (t in targets) {
            if (t < baseMinutes || t % baseMinutes != 0) continue
            val agg = Timeframes.aggregate(cs, t / baseMinutes)
            val label = Timeframes.label(t)
            if (agg.size < 55) { trends += TfTrend(label, Bias.NEUTRO, agg.size, "dados insuficientes (${agg.size} velas)"); continue }
            val c = agg.closes()
            val e21 = Indicators.ema(c, 21).lastValid(); val e50 = Indicators.ema(c, 50).lastValid()
            val st = MarketStructure.analyze(agg)
            val bias = when {
                e21 > e50 && c.last() > e21 && st.trend != Bias.BAIXA -> Bias.ALTA
                e21 < e50 && c.last() < e21 && st.trend != Bias.ALTA -> Bias.BAIXA
                else -> Bias.NEUTRO
            }
            trends += TfTrend(label, bias, agg.size, "EMA21 ${if (e21 > e50) ">" else "<"} EMA50; ${st.description}")
        }
        val valid = trends.filter { it.candles >= 55 }
        if (valid.isEmpty()) return MtfResult(trends, Bias.NEUTRO, Bias.NEUTRO, 0.0, emptyList(),
            "Dados insuficientes em todos os períodos disponíveis.")
        val sc = valid.map { when (it.bias) { Bias.ALTA -> 1.0; Bias.BAIXA -> -1.0; else -> 0.0 } }
        val dis = mutableListOf<String>()
        val ups = valid.filter { it.bias == Bias.ALTA }.map { it.label }
        val dns = valid.filter { it.bias == Bias.BAIXA }.map { it.label }
        if (ups.isNotEmpty() && dns.isNotEmpty()) dis += "Desacordo: alta em ${ups.joinToString()} x baixa em ${dns.joinToString()}"
        val primary = valid.last().bias
        val secondary = valid.first().bias
        return MtfResult(trends, primary, secondary, sc.average(), dis, "${valid.size} período(s) comparado(s)")
    }
}
