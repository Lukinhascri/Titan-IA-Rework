package com.titan.app.alerts

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import com.titan.app.core.Decision
import com.titan.app.core.SignalKind
import com.titan.app.core.VisualRead
import com.titan.app.data.AlertRow
import com.titan.app.data.Db

/** Estado de um alerta na tela (com contagem regressiva). */
data class LiveAlert(
    val dbId: Long, val asset: String, val kind: SignalKind, val bias: String, val criteria: String,
    val targetElapsed: Long?,          // SystemClock.elapsedRealtime() previsto (relógio monotônico)
    val readAgeSec: Long?,             // atraso da leitura que gerou o alerta
    val note: String
)

/**
 * Alertas antecipados. O "horário previsto" vem do relógio da VELA lido no print (tempo restante),
 * somado ao instante da leitura. Se a leitura estiver atrasada, isso é exibido (readAgeSec).
 */
class AlertEngine(private val ctx: Context, private val db: Db) {
    private var current: LiveAlert? = null
    private var lastKey: String? = null

    fun current() = current

    fun update(d: Decision, read: VisualRead?, nowElapsed: Long, nowWall: Long): LiveAlert? {
        val prev = current
        if (d.kind == SignalKind.AUSENCIA_DE_SINAL) {
            if (prev != null) {
                db.updateAlert(prev.dbId, "CANCELADO", "Condições deixaram de ser atendidas (${d.explanation.take(120)})")
                current = null; lastKey = null
            }
            return null
        }
        val key = "${d.asset}|${d.bias}|${d.kind}|${d.criteriaMet.size}"
        if (key == lastKey && prev != null) return prev
        val secLeft = read?.candleSecondsLeft
        val target = if (read != null && secLeft != null) nowElapsed - (nowWall - read.readAt) + secLeft * 1000L else null
        val targetWall = if (read != null && secLeft != null) read.readAt + secLeft * 1000L else null
        val crit = "OK: " + d.criteriaMet.joinToString("; ") + (if (d.criteriaMissing.isNotEmpty()) " | FALTAM: " + d.criteriaMissing.joinToString("; ") else "")
        if (prev != null) db.updateAlert(prev.dbId, "ATUALIZADO", "Substituído por novo estado: ${d.kind}")
        val id = db.insertAlert(AlertRow(0, nowWall, d.asset, d.kind.name, d.bias.name,
            targetWall, crit, "ATIVO", d.explanation))
        val la = LiveAlert(id, d.asset, d.kind, d.bias.name, crit, target,
            read?.let { (nowWall - it.readAt) / 1000 }, d.explanation)
        current = la; lastKey = key
        notify(la)
        return la
    }

    private fun notify(a: LiveAlert) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("titan_alerts", "Alertas TITAN", NotificationManager.IMPORTANCE_HIGH))
        val n = NotificationCompat.Builder(ctx, "titan_alerts")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("TITAN: ${a.kind.name.replace('_', ' ')} em ${a.asset}")
            .setContentText("Viés ${a.bias}. Hipótese baseada em dados passados — não é certeza.")
            .setStyle(NotificationCompat.BigTextStyle().bigText(a.criteria))
            .setAutoCancel(true).build()
        try { nm.notify(1001, n) } catch (_: SecurityException) { /* sem permissão de notificação */ }
    }
}
