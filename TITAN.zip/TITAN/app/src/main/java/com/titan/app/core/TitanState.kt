package com.titan.app.core

import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.titan.app.alerts.LiveAlert

enum class BubbleStatus { OFFLINE, CONECTADO, ANALISANDO, ALERTA, ERRO }

/** Estado global observável pela UI (Compose) e pela bolinha flutuante. */
object TitanState {
    var connected by mutableStateOf(false)
    var netType by mutableStateOf("sem rede")
    var latencyMs by mutableStateOf<Long?>(null)
    var dataUsedKb by mutableStateOf(0L)
    var analyzing by mutableStateOf(false)
    var captureActive by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var lastRead by mutableStateOf<VisualRead?>(null)
    var lastDecision by mutableStateOf<Decision?>(null)
    var liveAlert by mutableStateOf<LiveAlert?>(null)
    var lastBitmap: Bitmap? by mutableStateOf(null)       // último print (usado na calibração de cores)
    var paperMessage by mutableStateOf("")
    val log = mutableStateListOf<String>()

    fun say(msg: String) {
        log.add(0, java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date()) + "  " + msg)
        while (log.size > 80) log.removeAt(log.size - 1)
    }

    fun bubbleStatus(): BubbleStatus = when {
        error != null -> BubbleStatus.ERRO
        liveAlert != null -> BubbleStatus.ALERTA
        analyzing -> BubbleStatus.ANALISANDO
        connected || captureActive -> BubbleStatus.CONECTADO
        else -> BubbleStatus.OFFLINE
    }
}
